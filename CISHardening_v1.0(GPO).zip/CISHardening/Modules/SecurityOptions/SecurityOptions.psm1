#Requires -Version 5.1
#Requires -Modules GroupPolicy
<#
.SYNOPSIS
    CIS Hardening — Security Options Module
.DESCRIPTION
    Applies CIS security options via GPO registry settings.
    Covers: UAC, LM auth, SMB signing, WDigest, LSASS, LDAP, NTLM,
            anonymous access, machine account, logon settings.
    CIS Sections: 2.3.x
#>

function Invoke-SecurityOptionsHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'SecurityOptions'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Security Options hardening (Level: $Level)"

    # Registry settings: [Key, ValueName, Type, Value, CIS-Ref, Description]
    $settings = @(
        # LM / NTLM Authentication — 2.3.11.x
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa';                     V='LmCompatibilityLevel';                   T='DWord'; D=5;   R='2.3.11.7';  Desc='NTLMv2 only — refuse LM+NTLM' }
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa';                     V='NoLMHash';                               T='DWord'; D=1;   R='2.3.11.6';  Desc='Do not store LM hash' }
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa\MSV1_0';              V='NtlmMinClientSec';                       T='DWord'; D=537395200; R='2.3.11.9'; Desc='NTLM min client security: NTLMv2+128bit' }
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa\MSV1_0';              V='NtlmMinServerSec';                       T='DWord'; D=537395200; R='2.3.11.10'; Desc='NTLM min server security: NTLMv2+128bit' }
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa';                     V='RestrictAnonymous';                      T='DWord'; D=1;   R='2.3.11.2';  Desc='Restrict anonymous access to named pipes/shares' }
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa';                     V='RestrictAnonymousSAM';                   T='DWord'; D=1;   R='2.3.11.1';  Desc='No anonymous enumeration of SAM accounts' }
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa';                     V='EveryoneIncludesAnonymous';              T='DWord'; D=0;   R='2.3.11.3';  Desc='Let Everyone perms not apply to anonymous' }
        @{ K='HKLM\System\CurrentControlSet\Services\LanManServer\Parameters';V='NullSessionShares';                      T='MultiString'; D=''; R='2.3.11.4'; Desc='Null session shares — empty' }
        @{ K='HKLM\System\CurrentControlSet\Services\LanManServer\Parameters';V='NullSessionPipes';                       T='MultiString'; D=''; R='2.3.11.5'; Desc='Null session pipes — empty' }

        # WDigest — 2.3.x / 18.3.7
        @{ K='HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest'; V='UseLogonCredential'; T='DWord'; D=0; R='18.3.7'; Desc='WDigest disabled — no plaintext in memory' }

        # SMB Signing — 2.3.8.x
        @{ K='HKLM\System\CurrentControlSet\Services\LanManServer\Parameters'; V='RequireSecuritySignature'; T='DWord'; D=1; R='2.3.8.1'; Desc='SMB server signing required' }
        @{ K='HKLM\System\CurrentControlSet\Services\LanManServer\Parameters'; V='EnableSecuritySignature';  T='DWord'; D=1; R='2.3.8.2'; Desc='SMB server signing enabled' }
        @{ K='HKLM\System\CurrentControlSet\Services\LanManWorkstation\Parameters'; V='RequireSecuritySignature'; T='DWord'; D=1; R='2.3.8.3'; Desc='SMB client signing required' }
        @{ K='HKLM\System\CurrentControlSet\Services\LanManWorkstation\Parameters'; V='EnableSecuritySignature';  T='DWord'; D=1; R='2.3.8.4'; Desc='SMB client signing enabled' }

        # UAC — 2.3.17.x
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='EnableLUA';                    T='DWord'; D=1; R='2.3.17.1'; Desc='UAC: run all admins in approval mode' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='ConsentPromptBehaviorAdmin';   T='DWord'; D=2; R='2.3.17.2'; Desc='UAC: prompt admins for credentials on secure desktop' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='ConsentPromptBehaviorUser';    T='DWord'; D=0; R='2.3.17.3'; Desc='UAC: auto-deny standard user elevation requests' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='EnableInstallerDetection';     T='DWord'; D=1; R='2.3.17.4'; Desc='UAC: detect application installs' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='EnableSecureUIAPaths';         T='DWord'; D=1; R='2.3.17.5'; Desc='UAC: elevate only UIAccess apps from secure locations' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='LocalAccountTokenFilterPolicy';T='DWord'; D=0; R='2.3.17.6'; Desc='UAC: apply to network logons too' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='PromptOnSecureDesktop';        T='DWord'; D=1; R='2.3.17.7'; Desc='UAC: elevation prompt on secure desktop' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='ValidateAdminCodeSignatures';  T='DWord'; D=0; R='2.3.17.8'; Desc='UAC: no signature validation requirement' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='FilterAdministratorToken';     T='DWord'; D=1; R='2.3.17.9'; Desc='UAC: admin approval for built-in Administrator' }

        # Logon — 2.3.7.x
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='DontDisplayLastUserName';      T='DWord'; D=1; R='2.3.7.1'; Desc='Do not display last signed-in username' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='DisableCAD';                   T='DWord'; D=0; R='2.3.7.2'; Desc='CTRL+ALT+DEL required for logon' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='InactivityTimeoutSecs';        T='DWord'; D=900; R='2.3.7.3'; Desc='Machine inactivity lock: 900 seconds' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='LegalNoticeCaption';           T='String'; D='AUTHORIZED USE ONLY'; R='2.3.7.4'; Desc='Legal notice caption' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='LegalNoticeText';              T='String'; D='This system is restricted to authorized users. All activity is monitored and logged. Unauthorized access is prohibited.'; R='2.3.7.5'; Desc='Legal notice text' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; V='ScRemoveOption';               T='DWord'; D=1; R='2.3.7.6'; Desc='Smart card removal: lock workstation' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';     V='PasswordExpiryWarning';         T='DWord'; D=14; R='2.3.7.7'; Desc='Prompt user to change password 14 days before expiry' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';     V='CachedLogonsCount';             T='String'; D='4'; R='2.3.11.11'; Desc='Cached domain credential limit' }

        # Domain Member — 2.3.6.x
        @{ K='HKLM\System\CurrentControlSet\Services\Netlogon\Parameters';     V='RequireSignOrSeal';             T='DWord'; D=1; R='2.3.6.1'; Desc='Domain member: digitally encrypt or sign secure channel' }
        @{ K='HKLM\System\CurrentControlSet\Services\Netlogon\Parameters';     V='SealSecureChannel';             T='DWord'; D=1; R='2.3.6.2'; Desc='Domain member: encrypt secure channel when possible' }
        @{ K='HKLM\System\CurrentControlSet\Services\Netlogon\Parameters';     V='SignSecureChannel';             T='DWord'; D=1; R='2.3.6.3'; Desc='Domain member: sign secure channel when possible' }
        @{ K='HKLM\System\CurrentControlSet\Services\Netlogon\Parameters';     V='DisablePasswordChange';         T='DWord'; D=0; R='2.3.6.4'; Desc='Domain member: allow machine account password changes' }
        @{ K='HKLM\System\CurrentControlSet\Services\Netlogon\Parameters';     V='MaximumPasswordAge';            T='DWord'; D=30; R='2.3.6.5'; Desc='Domain member: max machine account password age 30 days' }
        @{ K='HKLM\System\CurrentControlSet\Services\Netlogon\Parameters';     V='RequireStrongKey';              T='DWord'; D=1; R='2.3.6.6'; Desc='Domain member: require strong session key' }

        # LDAP Client — 2.3.11.8
        @{ K='HKLM\System\CurrentControlSet\Services\LDAP';                    V='LDAPClientIntegrity';           T='DWord'; D=2; R='2.3.11.8'; Desc='LDAP client signing: require' }

        # PKU2U
        @{ K='HKLM\System\CurrentControlSet\Control\Lsa\pku2u';                V='AllowOnlineID';                 T='DWord'; D=0; R='2.3.11.11'; Desc='PKU2U: disable online identity authentication' }

        # Password reveal button
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\CredUI';                V='DisablePasswordReveal';         T='DWord'; D=1; R='18.x';    Desc='Disable password reveal button' }

        # Enumerate admin accounts on UAC elevation
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI'; V='EnumerateAdministrators';       T='DWord'; D=0; R='2.3.17.x'; Desc='Do not enumerate admin accounts on elevation' }

        # AutoAdminLogon — MSS
        @{ K='HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';     V='AutoAdminLogon';                T='String'; D='0'; R='MSS'; Desc='AutoAdminLogon disabled' }

        # Force logoff when logon hours expire
        @{ K='HKLM\System\CurrentControlSet\Services\LanManServer\Parameters'; V='EnableForcedLogOff';            T='DWord'; D=1; R='2.3.8.5'; Desc='Force logoff when logon hours expire' }
    )

    # DC-only settings
    $dcSettings = @(
        @{ K='HKLM\System\CurrentControlSet\Services\NTDS\Parameters';        V='LDAPServerIntegrity';            T='DWord'; D=2; R='2.3.11.x'; Desc='LDAP server signing: require (DC only)' }
        @{ K='HKLM\System\CurrentControlSet\Services\NTDS\Parameters';        V='LdapEnforceChannelBinding';      T='DWord'; D=2; R='2.3.11.9'; Desc='LDAP channel binding: always (DC only)' }
    )

    # DC-only: cached logons = 0
    if ($MachineInfo.IsDC) {
        $settings = $settings | Where-Object { $_.V -ne 'CachedLogonsCount' }
        $settings += @{ K='HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'; V='CachedLogonsCount'; T='String'; D='0'; R='2.3.7.x'; Desc='No cached credentials on DC' }
        $settings += $dcSettings
    }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Would apply $($settings.Count) security option registry values"
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-SecurityOptions-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Security Options — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            foreach ($s in $settings) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $s.K -ValueName $s.V -Type $s.T -Value $s.D -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set [$($s.R)] $($s.V) = $($s.D)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed to set $($s.V): $_"
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Security Options hardening complete — $($settings.Count) settings applied"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Security Options hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would apply $($settings.Count) security option settings"
        foreach ($s in $settings) {
            Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF]   [$($s.R)] $($s.V) = $($s.D) — $($s.Desc)"
        }
    }
}

Export-ModuleMember -Function Invoke-SecurityOptionsHardening
