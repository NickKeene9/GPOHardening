#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — User Rights Assignment Module
.DESCRIPTION
    Applies CIS user rights assignments via secedit INF and GPO.
    CIS Section: 2.2.x
#>

function Invoke-UserRightsHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'UserRights'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting User Rights hardening (Level: $Level, Role: $($MachineInfo.Role))"

    # Format: Constant = 'Account1,Account2' or '' for empty
    # *S-1-5-32-544 = Administrators
    # *S-1-5-32-545 = Users
    # *S-1-5-32-546 = Guests
    # *S-1-5-20     = Network Service
    # *S-1-5-19     = Local Service
    # *S-1-5-6      = Service
    # *S-1-5-11     = Authenticated Users

    $commonRights = [ordered]@{
        # 2.2.1 — Nobody gets this
        'SeTrustedCredManAccessPrivilege'    = ''
        # 2.2.2
        'SeNetworkLogonRight'               = '*S-1-5-32-544,*S-1-5-32-545'
        # 2.2.3 — Nobody
        'SeTcbPrivilege'                    = ''
        # 2.2.4
        'SeIncreaseQuotaPrivilege'          = '*S-1-5-19,*S-1-5-20,*S-1-5-32-544'
        # 2.2.5
        'SeInteractiveLogonRight'           = '*S-1-5-32-544'
        # 2.2.6
        'SeRemoteInteractiveLogonRight'     = '*S-1-5-32-544'
        # 2.2.7
        'SeBackupPrivilege'                 = '*S-1-5-32-544'
        # 2.2.8
        'SeSystemtimePrivilege'             = '*S-1-5-19,*S-1-5-32-544'
        # 2.2.9
        'SeTimeZonePrivilege'               = '*S-1-5-19,*S-1-5-32-544,*S-1-5-32-545'
        # 2.2.10 — Nobody
        'SeCreatePagefilePrivilege'         = '*S-1-5-32-544'
        # 2.2.11 — Nobody
        'SeCreateTokenPrivilege'            = ''
        # 2.2.12
        'SeCreateGlobalPrivilege'           = '*S-1-5-19,*S-1-5-20,*S-1-5-32-544,*S-1-5-6'
        # 2.2.13 — Nobody
        'SeCreatePermanentPrivilege'        = ''
        # 2.2.14
        'SeCreateSymbolicLinkPrivilege'     = '*S-1-5-32-544'
        # 2.2.15
        'SeDebugPrivilege'                  = '*S-1-5-32-544'
        # 2.2.16 — Nobody (Deny)
        'SeDenyNetworkLogonRight'           = '*S-1-5-32-546,*S-1-1-0'
        # 2.2.17 — Nobody (Deny)
        'SeDenyBatchLogonRight'             = '*S-1-5-32-546'
        # 2.2.18 — Nobody (Deny)
        'SeDenyServiceLogonRight'           = ''
        # 2.2.19 — Deny local logon to guests + local accounts
        'SeDenyInteractiveLogonRight'       = '*S-1-5-32-546'
        # 2.2.20 — Deny RDP to guests + local accounts
        'SeDenyRemoteInteractiveLogonRight' = '*S-1-5-32-546,*S-1-5-113'
        # 2.2.21
        'SeEnableDelegationPrivilege'       = ''
        # 2.2.22 — Remote shutdown
        'SeRemoteShutdownPrivilege'         = '*S-1-5-32-544'
        # 2.2.23
        'SeAuditPrivilege'                  = '*S-1-5-19,*S-1-5-20'
        # 2.2.24
        'SeImpersonatePrivilege'            = '*S-1-5-19,*S-1-5-20,*S-1-5-32-544,*S-1-5-6'
        # 2.2.25 — Increase scheduling priority
        'SeIncreaseBasePriorityPrivilege'   = '*S-1-5-32-544'
        # 2.2.26
        'SeLoadDriverPrivilege'             = '*S-1-5-32-544'
        # 2.2.27 — Lock pages
        'SeLockMemoryPrivilege'             = ''
        # 2.2.28
        'SeBatchLogonRight'                 = '*S-1-5-32-544'
        # 2.2.29 — Manage audit log
        'SeSecurityPrivilege'               = '*S-1-5-32-544'
        # 2.2.30
        'SeRelabelPrivilege'                = ''
        # 2.2.31
        'SeSystemEnvironmentPrivilege'      = '*S-1-5-32-544'
        # 2.2.32
        'SeManageVolumePrivilege'           = '*S-1-5-32-544'
        # 2.2.33
        'SeProfileSingleProcessPrivilege'   = '*S-1-5-32-544'
        # 2.2.34
        'SeSystemProfilePrivilege'          = '*S-1-5-32-544,*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420'
        # 2.2.35 — Restore files
        'SeRestorePrivilege'                = '*S-1-5-32-544'
        # 2.2.36
        'SeShutdownPrivilege'               = '*S-1-5-32-544'
        # 2.2.37
        'SeSyncAgentPrivilege'              = ''
        # 2.2.38
        'SeTakeOwnershipPrivilege'          = '*S-1-5-32-544'
        # 2.2.39 — Assign primary token
        'SeAssignPrimaryTokenPrivilege'     = '*S-1-5-19,*S-1-5-20'
    }

    # DC-specific overrides
    $dcRights = [ordered]@{
        'SeInteractiveLogonRight'       = '*S-1-5-32-544'
        'SeDenyNetworkLogonRight'       = '*S-1-5-32-546'
        'SeEnableDelegationPrivilege'   = ''
        'SeSyncAgentPrivilege'          = ''
    }

    # Member Server specific — block local account network logon (pass-the-hash)
    $msRights = [ordered]@{
        'SeDenyNetworkLogonRight'       = '*S-1-5-32-546,*S-1-5-113'
    }

    $rights = $commonRights.Clone()
    if ($MachineInfo.IsDC) {
        foreach ($k in $dcRights.Keys) { $rights[$k] = $dcRights[$k] }
        Write-HardeningLog -Level INFO -Module $mod -Message "DC overrides applied to user rights"
    } elseif ($MachineInfo.IsMemberServer) {
        foreach ($k in $msRights.Keys) { $rights[$k] = $msRights[$k] }
        Write-HardeningLog -Level INFO -Module $mod -Message "Member Server overrides applied — local accounts denied network logon"
    }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Would configure $($rights.Count) user rights assignments"
        return
    }

    if (-not $WhatIf) {
        try {
            # Build secedit INF
            $infLines = @('[Unicode]', 'Unicode=yes', '[Privilege Rights]')
            foreach ($entry in $rights.GetEnumerator()) {
                $infLines += "$($entry.Key) = $($entry.Value)"
            }
            $infLines += @('[Version]', 'signature="$CHICAGO$"', 'Revision = 1')

            $infPath = Join-Path $env:TEMP "cis_userrights_$($MachineInfo.Role).inf"
            $infLines -join "`n" | Out-File -FilePath $infPath -Encoding Unicode -Force

            $dbPath = Join-Path $env:TEMP 'cis_userrights.sdb'
            $result = & secedit.exe /configure /cfg $infPath /db $dbPath /areas USER_RIGHTS /quiet 2>&1
            if ($LASTEXITCODE -eq 0) {
                Write-HardeningLog -Level SUCCESS -Module $mod -Message "User rights applied via secedit — $($rights.Count) assignments"
            } else {
                Write-HardeningLog -Level WARN -Module $mod -Message "secedit returned: $result"
            }

            # Also create a GPO for persistence
            $gpoName = "CIS-$($MachineInfo.Role)-UserRights-$Level"
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level User Rights — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "User Rights hardening complete"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "User Rights hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would configure $($rights.Count) user rights assignments"
        foreach ($entry in $rights.GetEnumerator()) {
            $display = if ($entry.Value -eq '') { '(empty — no accounts)' } else { $entry.Value }
            Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF]   $($entry.Key) = $display"
        }
    }
}

Export-ModuleMember -Function Invoke-UserRightsHardening
