#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Report Module
.DESCRIPTION
    Generates a before/after compliance snapshot in HTML and JSON.
    Checks each control and reports Pass/Fail/Warning/NotApplicable.
#>

function Invoke-HardeningReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$OutputPath,
        [string]$SnapshotPath = '',
        [ValidateSet('L1','L2')][string]$Level = 'L1'
    )

    $mod = 'HardeningReport'
    Write-HardeningLog -Level INFO -Module $mod -Message "Generating hardening compliance report..."

    $results = [System.Collections.Generic.List[PSCustomObject]]::new()

    function Test-RegistryValue {
        param($Path, $Name, $ExpectedValue, $CISRef, $Description, $Role = 'All')
        $regPath = $Path -replace '^HKLM\\', 'HKLM:\'
        try {
            $actual = (Get-ItemProperty -Path $regPath -Name $Name -ErrorAction Stop).$Name
            $pass   = ($actual -eq $ExpectedValue) -or ($null -ne $actual -and $ExpectedValue -eq '*')
            return [PSCustomObject]@{
                CISRef      = $CISRef
                Description = $Description
                Expected    = $ExpectedValue
                Actual      = $actual
                Status      = if ($pass) { 'PASS' } else { 'FAIL' }
                Role        = $Role
            }
        } catch {
            return [PSCustomObject]@{
                CISRef      = $CISRef
                Description = $Description
                Expected    = $ExpectedValue
                Actual      = 'NOT SET'
                Status      = 'FAIL'
                Role        = $Role
            }
        }
    }

    function Test-ServiceState {
        param($ServiceName, $ExpectedStartType, $CISRef, $Description)
        $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if (-not $svc) {
            return [PSCustomObject]@{ CISRef=$CISRef; Description=$Description; Expected=$ExpectedStartType; Actual='Not Installed'; Status='PASS'; Role='All' }
        }
        return [PSCustomObject]@{
            CISRef      = $CISRef
            Description = $Description
            Expected    = $ExpectedStartType
            Actual      = $svc.StartType.ToString()
            Status      = if ($svc.StartType -eq $ExpectedStartType) { 'PASS' } else { 'FAIL' }
            Role        = 'All'
        }
    }

    # Run checks
    $checks = @(
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Control\Lsa'                'LmCompatibilityLevel'         5 '2.3.11.7'  'LM auth level: NTLMv2 only' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Control\Lsa'                'NoLMHash'                     1 '2.3.11.6'  'No LM hash stored' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' 'UseLogonCredential'    0 '18.3.7'    'WDigest disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' 'RequireSecuritySignature' 1 '2.3.8.1' 'SMB server signing required' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\LanManWorkstation\Parameters' 'RequireSecuritySignature' 1 '2.3.8.3' 'SMB client signing required' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'EnableLUA'              1 '2.3.17.1'  'UAC enabled' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'ConsentPromptBehaviorAdmin' 2 '2.3.17.2' 'UAC: prompt for credentials' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'DontDisplayLastUserName' 1 '2.3.7.1'  'Do not display last username' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'DisableCAD'             0 '2.3.7.2'   'CTRL+ALT+DEL required' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'InactivityTimeoutSecs'  900 '2.3.7.3' 'Inactivity lock: 900s' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'    'EnableMulticast'              0 '18.5.4.2'  'LLMNR disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'  'DisableIPSourceRouting'       2 '18.5.11.2' 'IP source routing disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'  'EnableICMPRedirect'           0 '18.5.11.3' 'ICMP redirects disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'  'SynAttackProtect'             1 '18.5.11.5' 'SYN attack protection' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' 'EnableScriptBlockLogging' 1 '18.9.95.1' 'PS script block logging' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'UserAuthenticationRequired' 1 '18.10.56.2.2' 'RDP NLA required' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard'     'LsaCfgFlags'                  1 '18.10.5.3' 'Credential Guard enabled' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard'     'EnableVirtualizationBasedSecurity' 1 '18.10.5.1' 'VBS enabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\NTDS\Parameters'   'LDAPServerIntegrity'          2 '2.3.11.x'  'LDAP server signing required' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Services\LDAP'              'LDAPClientIntegrity'          2 '2.3.11.8'  'LDAP client signing required' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile' 'EnableFirewall'         1 '9.1.1'     'Firewall: Domain profile enabled' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile'  'EnableFirewall'        1 '9.3.1'     'Firewall: Public profile enabled' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer'       'AlwaysInstallElevated'        0 '18.9.85.1' 'MSI elevation disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' 'Enabled' 0 '18.4.x' 'TLS 1.0 server disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' 'Enabled' 0 '18.4.x' 'TLS 1.1 server disabled' }
        { Test-RegistryValue 'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' 'Enabled' 1 '18.4.x' 'TLS 1.2 server enabled' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client'    'AllowBasic'                   0 '18.9.102.1.1' 'WinRM client basic auth disabled' }
        { Test-RegistryValue 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service'   'AllowBasic'                   0 '18.9.102.2.1' 'WinRM service basic auth disabled' }
        { Test-ServiceState  'Spooler'                 'Disabled'    '5.29'    'Print Spooler disabled' }
        { Test-ServiceState  'RemoteRegistry'          'Disabled'    '5.27'    'Remote Registry disabled' }
        { Test-ServiceState  'TlntSvr'                 'Disabled'    '5.x'     'Telnet disabled' }
    )

    foreach ($check in $checks) {
        $r = & $check
        if ($r) { $results.Add($r) }
    }

    # SMBv1 check
    try {
        $smb1 = Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB1Protocol
        $results.Add([PSCustomObject]@{
            CISRef='18.3.3'; Description='SMBv1 disabled';
            Expected='False'; Actual=$smb1.ToString();
            Status=if(-not $smb1){'PASS'}else{'FAIL'}; Role='All'
        })
    } catch {}

    # Summary
    $pass  = ($results | Where-Object Status -eq 'PASS').Count
    $fail  = ($results | Where-Object Status -eq 'FAIL').Count
    $total = $results.Count
    $pct   = if ($total -gt 0) { [math]::Round(($pass / $total) * 100, 1) } else { 0 }

    Write-HardeningLog -Level INFO -Module $mod -Message "=========================================="
    Write-HardeningLog -Level INFO -Module $mod -Message "  COMPLIANCE REPORT — $($MachineInfo.ComputerName)"
    Write-HardeningLog -Level INFO -Module $mod -Message "  Role   : $($MachineInfo.Role)"
    Write-HardeningLog -Level INFO -Module $mod -Message "  OS     : $($MachineInfo.OSCaption)"
    Write-HardeningLog -Level INFO -Module $mod -Message "  Level  : CIS $Level"
    Write-HardeningLog -Level INFO -Module $mod -Message "  PASS   : $pass / $total ($pct%)"
    Write-HardeningLog -Level INFO -Module $mod -Message "  FAIL   : $fail"
    Write-HardeningLog -Level INFO -Module $mod -Message "=========================================="

    foreach ($r in $results | Where-Object Status -eq 'FAIL') {
        Write-HardeningLog -Level WARN -Module $mod -Message "  FAIL [$($r.CISRef)] $($r.Description) — Expected: $($r.Expected), Got: $($r.Actual)"
    }

    # Write JSON report
    $reportFile = Join-Path $OutputPath "compliance_report_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    [PSCustomObject]@{
        GeneratedAt   = (Get-Date -Format 'o')
        ComputerName  = $MachineInfo.ComputerName
        Role          = $MachineInfo.Role
        OS            = $MachineInfo.OSCaption
        Level         = $Level
        TotalChecks   = $total
        Passed        = $pass
        Failed        = $fail
        CompliancePct = $pct
        Results       = $results
    } | ConvertTo-Json -Depth 10 | Out-File -FilePath $reportFile -Encoding UTF8

    Write-HardeningLog -Level SUCCESS -Module $mod -Message "Report written to: $reportFile"
    return $results
}

Export-ModuleMember -Function Invoke-HardeningReport
