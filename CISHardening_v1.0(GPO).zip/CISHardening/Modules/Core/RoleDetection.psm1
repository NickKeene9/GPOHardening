#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening Script — Role Detection Module
.DESCRIPTION
    Detects machine role (DC, Member Server, Workstation) and OS version.
    DomainRole values:
      0 = Standalone Workstation
      1 = Member Workstation
      2 = Standalone Server
      3 = Member Server
      4 = Backup Domain Controller
      5 = Primary Domain Controller
#>

function Get-MachineRole {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param()

    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop

    $role = switch ($cs.DomainRole) {
        { $_ -in 4,5 } { 'DomainController' }
        3              { 'MemberServer'      }
        { $_ -in 0,1 } { 'Workstation'       }
        2              { 'StandaloneServer'   }
        default        { 'Unknown'            }
    }

    $osCaption = $os.Caption
    $osBuild   = [System.Environment]::OSVersion.Version.Build

    $osTarget = switch -Regex ($osCaption) {
        'Server 2022' { 'Server2022' }
        'Server 2019' { 'Server2019' }
        'Server 2016' { 'Server2016' }
        'Windows 11'  { 'Windows11'  }
        'Windows 10'  { 'Windows10'  }
        default       { 'Unknown'    }
    }

    return @{
        Role          = $role
        DomainRole    = $cs.DomainRole
        OSCaption     = $osCaption
        OSTarget      = $osTarget
        OSBuild       = $osBuild
        Domain        = $cs.Domain
        ComputerName  = $cs.Name
        IsServer      = ($role -in 'DomainController','MemberServer','StandaloneServer')
        IsDC          = ($role -eq 'DomainController')
        IsMemberServer= ($role -eq 'MemberServer')
        IsWorkstation = ($role -eq 'Workstation')
    }
}

function Get-DCsInDomain {
    [CmdletBinding()]
    param()
    try {
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
        return $domain.DomainControllers | Select-Object -ExpandProperty Name
    } catch {
        Write-Warning "Unable to enumerate DCs: $_"
        return @()
    }
}

function Get-DomainControllersOU {
    [CmdletBinding()]
    param()
    try {
        $domain      = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
        $domainDN    = $domain.GetDirectoryEntry().distinguishedName
        return "OU=Domain Controllers,$domainDN"
    } catch {
        Write-Warning "Unable to resolve Domain Controllers OU: $_"
        return $null
    }
}

function Assert-ADModuleAvailable {
    if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
        throw "ActiveDirectory module not found. Install RSAT or run from a DC."
    }
    Import-Module ActiveDirectory -ErrorAction Stop
}

function Assert-GroupPolicyModuleAvailable {
    if (-not (Get-Module -ListAvailable -Name GroupPolicy)) {
        throw "GroupPolicy module not found. Install RSAT Group Policy Management Tools."
    }
    Import-Module GroupPolicy -ErrorAction Stop
}

Export-ModuleMember -Function Get-MachineRole, Get-DCsInDomain, Get-DomainControllersOU,
                               Assert-ADModuleAvailable, Assert-GroupPolicyModuleAvailable
