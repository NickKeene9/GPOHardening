#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening Script — Snapshot and Rollback Module
.DESCRIPTION
    Three-layer rollback system:
      Layer 1 — Backup-GPO  : full GPO backup before any changes
      Layer 2 — secedit     : local security DB export (.inf)
      Layer 3 — auditpol    : audit policy CSV export
    Tracks every GPO GUID created by the script in manifest.json.
    Invoke-HardeningRollback reverses all changes cleanly.
#>

$script:Manifest    = $null
$script:SnapshotDir = $null

function New-RollbackSnapshot {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$BaseOutputPath,
        [switch]$WhatIf
    )

    $ts              = Get-Date -Format 'yyyyMMdd_HHmmss'
    $script:SnapshotDir = Join-Path $BaseOutputPath "Rollback\$ts"

    $dirs = @(
        $script:SnapshotDir,
        (Join-Path $script:SnapshotDir 'GPOBackup')
    )
    foreach ($d in $dirs) { $null = New-Item -ItemType Directory -Path $d -Force }

    Write-HardeningLog -Level INFO -Module 'Snapshot' -Message "Snapshot directory: $script:SnapshotDir"

    # Layer 1 — Full GPO backup
    Write-HardeningLog -Level INFO -Module 'Snapshot' -Message "Backing up all GPOs..."
    if (-not $WhatIf) {
        try {
            Assert-GroupPolicyModuleAvailable
            $backupPath = Join-Path $script:SnapshotDir 'GPOBackup'
            Backup-GPO -All -Path $backupPath -ErrorAction Stop | Out-Null
            Write-HardeningLog -Level SUCCESS -Module 'Snapshot' -Message "GPO backup complete -> $backupPath"
        } catch {
            Write-HardeningLog -Level WARN -Module 'Snapshot' -Message "GPO backup failed: $_ (continuing)"
        }
    }

    # Layer 2 — secedit export
    $secInf = Join-Path $script:SnapshotDir 'secedit_pre.inf'
    Write-HardeningLog -Level INFO -Module 'Snapshot' -Message "Exporting local security policy..."
    if (-not $WhatIf) {
        $result = & secedit.exe /export /cfg $secInf /quiet 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-HardeningLog -Level SUCCESS -Module 'Snapshot' -Message "secedit export -> $secInf"
        } else {
            Write-HardeningLog -Level WARN -Module 'Snapshot' -Message "secedit export warning: $result"
        }
    }

    # Layer 3 — auditpol backup
    $auditCsv = Join-Path $script:SnapshotDir 'auditpol_pre.csv'
    Write-HardeningLog -Level INFO -Module 'Snapshot' -Message "Backing up audit policy..."
    if (-not $WhatIf) {
        $result = & auditpol.exe /backup /file:$auditCsv 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-HardeningLog -Level SUCCESS -Module 'Snapshot' -Message "auditpol backup -> $auditCsv"
        } else {
            Write-HardeningLog -Level WARN -Module 'Snapshot' -Message "auditpol backup warning: $result"
        }
    }

    # Initialise manifest
    $script:Manifest = [PSCustomObject]@{
        SnapshotTimestamp = $ts
        ComputerName      = $env:COMPUTERNAME
        CreatedBy         = "$($env:USERDOMAIN)\$($env:USERNAME)"
        WhatIf            = $WhatIf.IsPresent
        GPOsCreated       = [System.Collections.Generic.List[PSCustomObject]]::new()
        ModulesApplied    = [System.Collections.Generic.List[string]]::new()
        ServicesModified  = [System.Collections.Generic.List[PSCustomObject]]::new()
        RegistryKeys      = [System.Collections.Generic.List[PSCustomObject]]::new()
    }

    Save-Manifest
    return $script:SnapshotDir
}

function Register-CreatedGPO {
    param(
        [Parameter(Mandatory)][string]$GPOName,
        [Parameter(Mandatory)][string]$GPOGuid,
        [Parameter(Mandatory)][string]$Module,
        [string]$LinkedOU = ''
    )
    $entry = [PSCustomObject]@{
        GPOName   = $GPOName
        GPOGuid   = $GPOGuid
        Module    = $Module
        LinkedOU  = $LinkedOU
        CreatedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    }
    $script:Manifest.GPOsCreated.Add($entry)
    Save-Manifest
    Write-HardeningLog -Level DEBUG -Module 'Snapshot' -Message "Registered GPO: $GPOName ($GPOGuid)"
}

function Register-ModuleApplied {
    param([Parameter(Mandatory)][string]$ModuleName)
    $script:Manifest.ModulesApplied.Add($ModuleName)
    Save-Manifest
}

function Register-ServiceModified {
    param(
        [Parameter(Mandatory)][string]$ServiceName,
        [Parameter(Mandatory)][string]$OriginalStartType,
        [Parameter(Mandatory)][string]$NewStartType
    )
    $entry = [PSCustomObject]@{
        ServiceName       = $ServiceName
        OriginalStartType = $OriginalStartType
        NewStartType      = $NewStartType
        ModifiedAt        = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    }
    $script:Manifest.ServicesModified.Add($entry)
    Save-Manifest
}

function Save-Manifest {
    if ($null -eq $script:SnapshotDir) { return }
    $manifestPath = Join-Path $script:SnapshotDir 'manifest.json'
    $script:Manifest | ConvertTo-Json -Depth 10 | Out-File -FilePath $manifestPath -Encoding UTF8 -Force
}

function Get-SnapshotPath { return $script:SnapshotDir }

function Invoke-HardeningRollback {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$RollbackPath,
        [string]$Module = 'All',
        [switch]$WhatIf
    )

    Write-HardeningLog -Level WARN -Module 'Rollback' -Message "=== ROLLBACK INITIATED ==="

    $manifestPath = Join-Path $RollbackPath 'manifest.json'
    if (-not (Test-Path $manifestPath)) {
        Write-HardeningLog -Level ERROR -Module 'Rollback' -Message "Manifest not found at $manifestPath"
        throw "Cannot rollback — manifest.json missing from $RollbackPath"
    }

    $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
    Write-HardeningLog -Level INFO -Module 'Rollback' -Message "Snapshot from: $($manifest.SnapshotTimestamp) on $($manifest.ComputerName)"

    # Step 1 — Remove created GPOs
    $gposToRemove = if ($Module -eq 'All') {
        $manifest.GPOsCreated
    } else {
        $manifest.GPOsCreated | Where-Object Module -eq $Module
    }

    Assert-GroupPolicyModuleAvailable
    foreach ($gpo in $gposToRemove) {
        Write-HardeningLog -Level INFO -Module 'Rollback' -Message "Removing GPO: $($gpo.GPOName) ($($gpo.GPOGuid))"
        if (-not $WhatIf) {
            try {
                if ($gpo.LinkedOU) {
                    Remove-GPLink -Name $gpo.GPOName -Target $gpo.LinkedOU -ErrorAction SilentlyContinue
                }
                Remove-GPO -Name $gpo.GPOName -ErrorAction Stop
                Write-HardeningLog -Level SUCCESS -Module 'Rollback' -Message "Removed GPO: $($gpo.GPOName)"
            } catch {
                Write-HardeningLog -Level WARN -Module 'Rollback' -Message "Could not remove $($gpo.GPOName): $_"
            }
        }
    }

    if ($Module -eq 'All') {
        # Step 2 — Restore secedit
        $secInf = Join-Path $RollbackPath 'secedit_pre.inf'
        if (Test-Path $secInf) {
            Write-HardeningLog -Level INFO -Module 'Rollback' -Message "Restoring security policy from $secInf"
            if (-not $WhatIf) {
                $db = Join-Path $env:TEMP 'secedit_rollback.sdb'
                & secedit.exe /configure /cfg $secInf /db $db /quiet 2>&1 | Out-Null
                Write-HardeningLog -Level SUCCESS -Module 'Rollback' -Message "Security policy restored"
            }
        }

        # Step 3 — Restore auditpol
        $auditCsv = Join-Path $RollbackPath 'auditpol_pre.csv'
        if (Test-Path $auditCsv) {
            Write-HardeningLog -Level INFO -Module 'Rollback' -Message "Restoring audit policy from $auditCsv"
            if (-not $WhatIf) {
                & auditpol.exe /restore /file:$auditCsv 2>&1 | Out-Null
                Write-HardeningLog -Level SUCCESS -Module 'Rollback' -Message "Audit policy restored"
            }
        }

        # Step 4 — Restore services
        foreach ($svc in $manifest.ServicesModified) {
            Write-HardeningLog -Level INFO -Module 'Rollback' -Message "Restoring service $($svc.ServiceName) to $($svc.OriginalStartType)"
            if (-not $WhatIf) {
                try {
                    Set-Service -Name $svc.ServiceName -StartupType $svc.OriginalStartType -ErrorAction Stop
                    if ($svc.OriginalStartType -in 'Automatic','Manual') {
                        Start-Service -Name $svc.ServiceName -ErrorAction SilentlyContinue
                    }
                    Write-HardeningLog -Level SUCCESS -Module 'Rollback' -Message "Restored: $($svc.ServiceName)"
                } catch {
                    Write-HardeningLog -Level WARN -Module 'Rollback' -Message "Could not restore $($svc.ServiceName): $_"
                }
            }
        }
    }

    Write-HardeningLog -Level SUCCESS -Module 'Rollback' -Message "=== ROLLBACK COMPLETE — run gpupdate /force on targets ==="
    Write-HardeningLog -Level WARN   -Module 'Rollback' -Message "TLS changes require a REBOOT to take effect."
}

Export-ModuleMember -Function New-RollbackSnapshot, Register-CreatedGPO, Register-ModuleApplied,
                               Register-ServiceModified, Save-Manifest, Get-SnapshotPath,
                               Invoke-HardeningRollback
