#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening Script — Logging Module
.DESCRIPTION
    Centralised logging, transcript management, and structured output
    for the CIS AD GPO Hardening Script.
#>

$script:LogPath     = $null
$script:LogLevel    = 'INFO'
$script:LogEntries  = [System.Collections.Generic.List[PSCustomObject]]::new()
$script:WhatIfMode  = $false

function Initialize-HardeningLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$OutputPath,
        [ValidateSet('DEBUG','INFO','WARN','ERROR')][string]$Level = 'INFO',
        [switch]$WhatIf
    )
    $script:LogPath    = Join-Path $OutputPath "hardening_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    $script:LogLevel   = $Level
    $script:WhatIfMode = $WhatIf.IsPresent
    $null = New-Item -ItemType Directory -Path $OutputPath -Force

    $header = @"
================================================================================
  CIS AD GPO Hardening Script
  Started  : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  Host     : $($env:COMPUTERNAME)
  User     : $($env:USERDOMAIN)\$($env:USERNAME)
  WhatIf   : $($script:WhatIfMode)
================================================================================
"@
    $header | Out-File -FilePath $script:LogPath -Encoding UTF8
    Write-HardeningLog -Level INFO -Message "Log initialised at $script:LogPath"
}

function Write-HardeningLog {
    [CmdletBinding()]
    param(
        [ValidateSet('DEBUG','INFO','WARN','ERROR','SUCCESS')][string]$Level = 'INFO',
        [Parameter(Mandatory)][string]$Message,
        [string]$Module = 'Core',
        [switch]$NoConsole
    )

    $order = @{ DEBUG=0; INFO=1; WARN=2; ERROR=3; SUCCESS=1 }
    if ($order[$Level] -lt $order[$script:LogLevel] -and $Level -ne 'SUCCESS') { return }

    $ts    = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = [PSCustomObject]@{
        Timestamp = $ts
        Level     = $Level
        Module    = $Module
        Message   = $Message
    }
    $script:LogEntries.Add($entry)

    $line = "[$ts] [$($Level.PadRight(7))] [$($Module.PadRight(20))] $Message"

    if ($script:LogPath) {
        $line | Out-File -FilePath $script:LogPath -Append -Encoding UTF8
    }

    if (-not $NoConsole) {
        $color = switch ($Level) {
            'DEBUG'   { 'Gray' }
            'INFO'    { 'Cyan' }
            'WARN'    { 'Yellow' }
            'ERROR'   { 'Red' }
            'SUCCESS' { 'Green' }
            default   { 'White' }
        }
        Write-Host $line -ForegroundColor $color
    }
}

function Get-HardeningLog {
    return $script:LogEntries
}

function Close-HardeningLog {
    $footer = @"
================================================================================
  Completed: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  Total entries: $($script:LogEntries.Count)
  Errors : $(($script:LogEntries | Where-Object Level -eq 'ERROR').Count)
  Warnings: $(($script:LogEntries | Where-Object Level -eq 'WARN').Count)
================================================================================
"@
    if ($script:LogPath) {
        $footer | Out-File -FilePath $script:LogPath -Append -Encoding UTF8
    }
    Write-Host $footer -ForegroundColor DarkGray
}

Export-ModuleMember -Function Initialize-HardeningLog, Write-HardeningLog, Get-HardeningLog, Close-HardeningLog
