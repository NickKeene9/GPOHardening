#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Registry Hardening Module
.DESCRIPTION
    Applies CIS registry settings not covered by other modules.
    Credential Guard, VBS, HVCI, DEP, SEHOP, PowerShell logging,
    RDP hardening, Autorun, DLL search order, error reporting.
    CIS Sections: 18.x, MSS settings
#>

function Invoke-RegistryHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'RegistryHardening'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Registry hardening (Level: $Level)"

    $settings = @(
        # Credential Guard — 18.10.5.1
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard'; V='EnableVirtualizationBasedSecurity';  T='DWord'; D=1; R='18.10.5.1'; Desc='Virtualization Based Security enabled' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard'; V='RequirePlatformSecurityFeatures';    T='DWord'; D=3; R='18.10.5.2'; Desc='VBS: require Secure Boot + DMA protection' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard'; V='LsaCfgFlags';                       T='DWord'; D=1; R='18.10.5.3'; Desc='Credential Guard: enabled with UEFI lock' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard'; V='HypervisorEnforcedCodeIntegrity';   T='DWord'; D=1; R='18.10.5.4'; Desc='HVCI: enabled (blocks unsigned kernel drivers)' }

        # Autorun / Autoplay — 18.9.8.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer';    V='NoAutoplayfornonVolume';             T='DWord'; D=1; R='18.9.8.1'; Desc='Autoplay disabled for non-volume devices' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'; V='NoDriveTypeAutoRun';    T='DWord'; D=255; R='18.9.8.2'; Desc='Autorun disabled for all drives' }
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'; V='NoAutorun';             T='DWord'; D=1; R='18.9.8.3'; Desc='Autorun actions disabled' }

        # Safe DLL search — MSS
        @{ K='HKLM\SYSTEM\CurrentControlSet\Control\Session Manager'; V='SafeDllSearchMode';                T='DWord'; D=1; R='MSS'; Desc='Safe DLL search mode — prevent DLL hijacking' }

        # SEHOP — MSS (18.3.4)
        @{ K='HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel'; V='DisableExceptionChainValidation'; T='DWord'; D=0; R='18.3.4'; Desc='SEHOP enabled' }

        # PowerShell logging — 18.9.95.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging';    V='EnableScriptBlockLogging'; T='DWord'; D=1; R='18.9.95.1'; Desc='PS script block logging enabled' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging';    V='EnableScriptBlockInvocationLogging'; T='DWord'; D=0; R='18.9.95.2'; Desc='PS invocation logging disabled (high volume)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging';         V='EnableModuleLogging'; T='DWord'; D=1; R='18.9.95.3'; Desc='PS module logging enabled' }

        # RDP hardening — 18.10.56.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='UserAuthenticationRequired'; T='DWord'; D=1; R='18.10.56.2.2'; Desc='RDP NLA required' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='MinEncryptionLevel';          T='DWord'; D=3; R='18.10.56.2.3'; Desc='RDP encryption level: High (3)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='SecurityLayer';               T='DWord'; D=2; R='18.10.56.2.4'; Desc='RDP security layer: SSL (2)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='fAllowToGetHelp';             T='DWord'; D=0; R='18.10.56.3.1'; Desc='Solicited Remote Assistance disabled' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='MaxIdleTime';                 T='DWord'; D=900000; R='18.10.56.3.2'; Desc='RDP idle session limit: 15 min' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='MaxDisconnectionTime';        T='DWord'; D=60000; R='18.10.56.3.3'; Desc='RDP disconnected session limit: 1 min' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; V='fPromptForPassword';          T='DWord'; D=1; R='18.10.56.3.4'; Desc='Always prompt for RDP password' }

        # Windows Installer — 18.9.85.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer';   V='AlwaysInstallElevated';              T='DWord'; D=0; R='18.9.85.1'; Desc='Windows Installer elevation disabled (HKLM)' }
        @{ K='HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer';   V='AlwaysInstallElevated';              T='DWord'; D=0; R='18.9.85.2'; Desc='Windows Installer elevation disabled (HKCU)' }

        # Error reporting — 18.9.15.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting'; V='Disabled'; T='DWord'; D=1; R='18.9.15.1'; Desc='Windows Error Reporting disabled' }

        # Telemetry — 18.9.17.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; V='AllowTelemetry';                  T='DWord'; D=0; R='18.9.17.1'; Desc='Telemetry: Security level only (0)' }

        # Font providers — 18.9.26.1
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\System'; V='EnableFontProviders';                     T='DWord'; D=0; R='18.9.26.1'; Desc='Online font provider disabled' }

        # OneDrive sync — 18.9.61.1 (servers)
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive';    V='DisableFileSyncNGSC';               T='DWord'; D=1; R='18.9.61.1'; Desc='OneDrive sync disabled' }

        # Event log sizes — 18.9.27.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application'; V='MaxSize'; T='DWord'; D=32768;   R='18.9.27.1.1'; Desc='Application log max size: 32MB' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security';    V='MaxSize'; T='DWord'; D=1048576;  R='18.9.27.2.1'; Desc='Security log max size: 1GB' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\System';      V='MaxSize'; T='DWord'; D=32768;   R='18.9.27.3.1'; Desc='System log max size: 32MB' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application'; V='Retention'; T='String'; D='0';  R='18.9.27.1.2'; Desc='Application log: overwrite as needed' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security';    V='Retention'; T='String'; D='0';  R='18.9.27.2.2'; Desc='Security log: overwrite as needed' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\EventLog\System';      V='Retention'; T='String'; D='0';  R='18.9.27.3.2'; Desc='System log: overwrite as needed' }
    )

    # L2 additional settings
    $l2Settings = @(
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription'; V='EnableTranscripting'; T='DWord'; D=1; R='18.9.95.4'; Desc='PS transcription logging enabled (L2)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services';     V='fDisableClip';         T='DWord'; D=1; R='18.10.56.3.9.3'; Desc='RDP clipboard redirection disabled (L2)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services';     V='fDisableCdm';          T='DWord'; D=1; R='18.10.56.3.9.5'; Desc='RDP drive mapping disabled (L2)' }
    )

    # Server-only settings
    $serverSettings = @(
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'; V='AutoShareServer'; T='DWord'; D=1; R='18.x'; Desc='Admin shares retained on servers (required for management)' }
    )

    $allSettings = $settings
    if ($Level -eq 'L2') { $allSettings += $l2Settings }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Would apply $($allSettings.Count) registry hardening settings"
        # Check Credential Guard prereqs
        $vbs = (Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -ErrorAction SilentlyContinue)?.EnableVirtualizationBasedSecurity
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Current VBS setting: $(if($null -eq $vbs){'Not set'}else{$vbs})"
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-RegistryHardening-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Registry Hardening — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            foreach ($s in $allSettings) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $s.K -ValueName $s.V -Type $s.T -Value $s.D -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set [$($s.R)] $($s.V) = $($s.D)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed: $($s.V): $_"
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Registry hardening complete — $($allSettings.Count) settings applied"
            Write-HardeningLog -Level WARN    -Module $mod -Message "Credential Guard (LsaCfgFlags) requires UEFI + VBS hardware + reboot"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Registry hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would apply $($allSettings.Count) registry settings"
    }
}

Export-ModuleMember -Function Invoke-RegistryHardening
