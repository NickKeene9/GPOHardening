#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Network Hardening Module
.DESCRIPTION
    Disables LLMNR, NetBIOS, WPAD, mDNS, SMBv1. Hardens TCP/IP stack.
    Restricts NTLM traffic. Disables source routing and ICMP redirects.
    CIS Sections: 18.5.x, 18.3.x
#>

function Invoke-NetworkHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'NetworkHardening'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Network hardening (Level: $Level)"

    $settings = @(
        # LLMNR — 18.5.4.2
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'; V='EnableMulticast';           T='DWord'; D=0; R='18.5.4.2'; Desc='LLMNR disabled' }
        # WPAD
        @{ K='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad';  V='WpadOverride';          T='DWord'; D=1; R='18.5.x'; Desc='WPAD override disabled' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings'; V='ProxySettingsPerUser'; T='DWord'; D=0; R='18.5.x'; Desc='WPAD proxy per-user disabled' }
        # Source routing — 18.5.11.2
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';            V='DisableIPSourceRouting';     T='DWord'; D=2; R='18.5.11.2'; Desc='IP source routing disabled (drop packets)' }
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters';           V='DisableIPSourceRouting';     T='DWord'; D=2; R='18.5.11.3'; Desc='IPv6 source routing disabled' }
        # ICMP redirects — 18.5.11.3
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';            V='EnableICMPRedirect';         T='DWord'; D=0; R='18.5.11.3'; Desc='ICMP redirects disabled' }
        # SYN attack protection — 18.5.11.5
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';            V='SynAttackProtect';           T='DWord'; D=1; R='18.5.11.5'; Desc='SYN attack protection enabled' }
        # NetBT — 18.5.5.x
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\NetBT\Parameters';            V='NodeType';                   T='DWord'; D=2; R='18.5.5.1'; Desc='NetBIOS node type: P-node (no broadcasts)' }
        # Network bridge — 18.5.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\Network Connections';       V='NC_AllowNetBridge_NLA';      T='DWord'; D=0; R='18.5.x'; Desc='Network bridge prohibited' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\Network Connections';       V='NC_StdDomainUserSetLocation'; T='DWord'; D=1; R='18.5.x'; Desc='Standard users cannot change network location' }
        # Simultaneous connections — 18.5.x
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy';        V='fMinimizeConnections';        T='DWord'; D=3; R='18.5.x'; Desc='Minimise simultaneous connections to internet' }
        # NTLM outbound restriction
        @{ K='HKLM\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0';                  V='RestrictSendingNTLMTraffic';  T='DWord'; D=1; R='2.3.11.x'; Desc='NTLM outbound: audit mode (1=audit, 2=deny)' }
    )

    # DC-only NTLM inbound audit
    $dcSettings = @(
        @{ K='HKLM\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0'; V='AuditReceivingNTLMTraffic'; T='DWord'; D=2; R='2.3.11.x'; Desc='NTLM inbound: audit all (DC)' }
        @{ K='HKLM\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0'; V='RestrictNTLMInDomain';      T='DWord'; D=1; R='2.3.11.x'; Desc='NTLM in-domain: audit (DC)' }
    )

    # L2 additions
    $l2Settings = @(
        @{ K='HKLM\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'; V='DisabledComponents'; T='DWord'; D=0xFF; R='18.5.x'; Desc='IPv6 disabled (L2)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient';    V='DoHPolicy';           T='DWord'; D=2;    R='18.5.x'; Desc='DNS over HTTPS: allow (L2, workstations)' }
    )

    if ($MachineInfo.IsDC) { $settings += $dcSettings }
    if ($Level -eq 'L2')   { $settings += $l2Settings }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking network configuration..."

        # Check for SMBv1
        try {
            $smb1 = Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB1Protocol
            $status = if ($smb1) { 'ENABLED — MUST be disabled' } else { 'Already disabled' }
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] SMBv1: $status"
        } catch { Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] Could not check SMBv1 status" }

        # Check active SMB sessions
        $sessions = Get-SmbSession -ErrorAction SilentlyContinue
        if ($sessions) {
            Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] $($sessions.Count) active SMB sessions — verify none are SMBv1"
        }

        # LLMNR check
        $llmnr = (Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMulticast' -ErrorAction SilentlyContinue)?.EnableMulticast
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] LLMNR: $(if ($null -eq $llmnr -or $llmnr -eq 1) { 'ENABLED — will be disabled' } else { 'Already disabled' })"

        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-NetworkHardening-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Network Hardening — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            foreach ($s in $settings) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $s.K -ValueName $s.V -Type $s.T -Value $s.D -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set [$($s.R)] $($s.V) = $($s.D)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed: $($s.V): $_"
                }
            }

            # SMBv1 — direct disable (GPO path does not control this cleanly)
            Write-HardeningLog -Level INFO -Module $mod -Message "Disabling SMBv1 via Set-SmbServerConfiguration..."
            Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "SMBv1 disabled"

            # SMBv2 idle disconnect
            Set-SmbServerConfiguration -AutoDisconnectTimeout 15 -Force -ErrorAction SilentlyContinue
            Write-HardeningLog -Level DEBUG -Module $mod -Message "SMBv2 idle timeout: 15 minutes"

            # NetBIOS over TCP/IP — disable per adapter via WMI
            Write-HardeningLog -Level INFO -Module $mod -Message "Disabling NetBIOS over TCP/IP on all adapters..."
            $adapters = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction SilentlyContinue
            foreach ($adapter in $adapters) {
                $result = $adapter.SetTcpipNetbios(2)  # 2 = Disable NetBIOS over TCP/IP
                if ($result.ReturnValue -eq 0) {
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "NetBIOS disabled on: $($adapter.Description)"
                } else {
                    Write-HardeningLog -Level WARN -Module $mod -Message "NetBIOS disable failed on $($adapter.Description): return $($result.ReturnValue)"
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Network hardening complete"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Network hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would disable LLMNR, NetBIOS, WPAD, SMBv1, source routing, ICMP redirects"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would set SYN attack protection, restrict NTLM"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] $($settings.Count) registry settings + SMBv1 direct disable + per-adapter NetBIOS disable"
    }
}

Export-ModuleMember -Function Invoke-NetworkHardening
