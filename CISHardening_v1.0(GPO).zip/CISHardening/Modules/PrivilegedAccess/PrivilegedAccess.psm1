#Requires -Version 5.1
#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    CIS Hardening — Privileged Access Module
.DESCRIPTION
    Enforces Restricted Groups (Enterprise/Schema Admins empty when not in use),
    Protected Users group enforcement, DSRM password policy, LAPS verification,
    unconstrained delegation audit, AdminSDHolder monitoring.
    DC-only module.
#>

function Invoke-PrivilegedAccessHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode,
        [switch]$SkipRestrictedGroups
    )

    $mod = 'PrivilegedAccess'

    if (-not $MachineInfo.IsDC) {
        Write-HardeningLog -Level INFO -Module $mod -Message "Skipping PrivilegedAccess — DC-only module (role: $($MachineInfo.Role))"
        return
    }

    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Privileged Access hardening (DC role confirmed)"
    Assert-ADModuleAvailable

    $domain = Get-ADDomain -ErrorAction Stop

    # ── Audit: Unconstrained Delegation ──────────────────────────────────────
    Write-HardeningLog -Level INFO -Module $mod -Message "Auditing accounts with unconstrained delegation..."
    $unconstrainedAccounts = Get-ADComputer -Filter { TrustedForDelegation -eq $true } -Properties TrustedForDelegation, Name -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne ($domain.PDCEmulator.Split('.')[0]) }
    $unconstrainedUsers = Get-ADUser -Filter { TrustedForDelegation -eq $true } -Properties TrustedForDelegation, SamAccountName -ErrorAction SilentlyContinue

    if ($unconstrainedAccounts) {
        Write-HardeningLog -Level WARN -Module $mod -Message "WARNING: $($unconstrainedAccounts.Count) computer accounts with unconstrained delegation:"
        foreach ($a in $unconstrainedAccounts) {
            Write-HardeningLog -Level WARN -Module $mod -Message "  COMPUTER: $($a.Name) — review if constrained delegation can replace this"
        }
    }
    if ($unconstrainedUsers) {
        Write-HardeningLog -Level WARN -Module $mod -Message "WARNING: $($unconstrainedUsers.Count) user accounts with unconstrained delegation:"
        foreach ($u in $unconstrainedUsers) {
            Write-HardeningLog -Level WARN -Module $mod -Message "  USER: $($u.SamAccountName) — MUST be reviewed and remediated"
        }
    }
    if (-not $unconstrainedAccounts -and -not $unconstrainedUsers) {
        Write-HardeningLog -Level SUCCESS -Module $mod -Message "No accounts with unconstrained delegation found"
    }

    # ── Audit: Local Admin membership ─────────────────────────────────────────
    Write-HardeningLog -Level INFO -Module $mod -Message "Auditing local Administrators group membership..."
    $localAdmins = Get-LocalGroupMember -Group 'Administrators' -ErrorAction SilentlyContinue
    foreach ($member in $localAdmins) {
        Write-HardeningLog -Level INFO -Module $mod -Message "  Local Admin: $($member.Name) ($($member.PrincipalSource))"
    }

    # ── Audit: LAPS deployment ────────────────────────────────────────────────
    Write-HardeningLog -Level INFO -Module $mod -Message "Checking LAPS deployment..."
    $lapsAttr = Get-ADObject -SearchBase $domain.DistinguishedName -LDAPFilter '(objectClass=attributeSchema)(name=ms-Mcs-AdmPwd)' `
        -SearchScope Subtree -Properties name -ErrorAction SilentlyContinue
    if ($lapsAttr) {
        Write-HardeningLog -Level SUCCESS -Module $mod -Message "LAPS schema attributes present"
        # Check for computers without LAPS password set
        $noLaps = Get-ADComputer -Filter * -Properties 'ms-Mcs-AdmPwdExpirationTime' -ErrorAction SilentlyContinue |
            Where-Object { -not $_.'ms-Mcs-AdmPwdExpirationTime' } | Select-Object -ExpandProperty Name
        if ($noLaps) {
            Write-HardeningLog -Level WARN -Module $mod -Message "  $($noLaps.Count) computers without LAPS password set — ensure LAPS GPO covers all machines"
        } else {
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "  All computers have LAPS passwords configured"
        }
    } else {
        Write-HardeningLog -Level WARN -Module $mod -Message "LAPS schema attributes NOT found — LAPS not deployed. Install Windows LAPS or legacy LAPS before deploying."
    }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] PrivilegedAccess audit complete — no changes made"
        return
    }

    $gpoName = "CIS-DomainController-PrivilegedAccess-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Privileged Access — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            # Protected Users enforcement via registry note
            # (Actual group membership managed separately via AGPM/manual process)
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\SYSTEM\CurrentControlSet\Control\Lsa' `
                -ValueName 'ProtectedUsersSecurity' -Type DWord -Value 1 | Out-Null

            # AdminSDHolder — set SDPropInterval to 60 minutes (default 60, CIS recommends leaving default)
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\SYSTEM\CurrentControlSet\Services\NTDS\Parameters' `
                -ValueName 'AdminSDProtectFrequency' -Type DWord -Value 3600 | Out-Null

            # Enforce Protected Users GPO setting
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' `
                -ValueName 'RunLogonScriptSync' -Type DWord -Value 1 | Out-Null

            # Restricted Groups — Enterprise Admins and Schema Admins empty
            if (-not $SkipRestrictedGroups) {
                Write-HardeningLog -Level INFO -Module $mod -Message "Configuring Restricted Groups (Enterprise Admins, Schema Admins)..."
                Write-HardeningLog -Level WARN  -Module $mod -Message "Restricted Groups will enforce empty membership on Enterprise Admins and Schema Admins."
                Write-HardeningLog -Level WARN  -Module $mod -Message "Ensure break-glass accounts are documented before proceeding."

                # Note: Restricted Groups via GPO is best configured through GPMC UI or
                # by writing the GptTmpl.inf directly — we document the intent here and
                # advise manual GPO configuration for this specific setting to prevent
                # accidental lockout.
                Write-HardeningLog -Level WARN -Module $mod -Message "MANUAL ACTION REQUIRED: Configure Restricted Groups for 'Enterprise Admins' and 'Schema Admins'"
                Write-HardeningLog -Level WARN -Module $mod -Message "  in GPO: $gpoName"
                Write-HardeningLog -Level WARN -Module $mod -Message "  Path: Computer Config > Policies > Windows Settings > Security Settings > Restricted Groups"
                Write-HardeningLog -Level WARN -Module $mod -Message "  Set both groups to empty (members: none) for enforcement when not in use."
            }

            # Verify privileged group membership and log it
            $sensitiveGroups = @('Domain Admins','Enterprise Admins','Schema Admins','Administrators','Account Operators','Backup Operators')
            foreach ($grp in $sensitiveGroups) {
                try {
                    $members = Get-ADGroupMember -Identity $grp -Recursive -ErrorAction SilentlyContinue
                    Write-HardeningLog -Level INFO -Module $mod -Message "  $grp : $($members.Count) members"
                    foreach ($m in $members) {
                        Write-HardeningLog -Level DEBUG -Module $mod -Message "    $($m.SamAccountName) ($($m.objectClass))"
                    }
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "  Could not enumerate $grp : $_"
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Privileged Access hardening complete"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Privileged Access hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would audit and enforce privileged access controls on DC"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would create GPO: $gpoName"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would document Restricted Groups manual action for Enterprise/Schema Admins"
    }
}

Export-ModuleMember -Function Invoke-PrivilegedAccessHardening
