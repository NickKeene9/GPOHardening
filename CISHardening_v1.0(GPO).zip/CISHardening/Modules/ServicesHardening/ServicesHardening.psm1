#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Services Hardening Module
.DESCRIPTION
    Disables legacy and unnecessary services. Pre-checks active
    Print Spooler queues before disabling. Records original service
    start types for rollback.
    CIS Section: 5.x
#>

function Invoke-ServicesHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'ServicesHardening'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Services hardening (Level: $Level, Role: $($MachineInfo.Role))"

    # Service definitions: Name, CIS-Ref, Description, Roles, Level
    $servicesToDisable = @(
        @{ Name='TlntSvr';         Ref='5.x';   Desc='Telnet — plaintext protocol';              Roles=@('DomainController','MemberServer','Workstation'); Level='L1' }
        @{ Name='MSFTPSVC';        Ref='5.x';   Desc='FTP Publishing Service — plaintext';       Roles=@('DomainController','MemberServer');               Level='L1' }
        @{ Name='RemoteRegistry';  Ref='5.27';  Desc='Remote Registry — no remote reg access';  Roles=@('DomainController','MemberServer','Workstation'); Level='L1' }
        @{ Name='SNMP';            Ref='5.x';   Desc='SNMP Service — unless required+hardened'; Roles=@('DomainController','MemberServer','Workstation'); Level='L1' }
        @{ Name='SNMPTrap';        Ref='5.x';   Desc='SNMP Trap — disable if SNMP not in use'; Roles=@('DomainController','MemberServer','Workstation'); Level='L1' }
        @{ Name='Browser';         Ref='5.x';   Desc='Computer Browser — legacy browser proto'; Roles=@('DomainController','MemberServer','Workstation'); Level='L1' }
        @{ Name='simptcp';         Ref='5.x';   Desc='Simple TCP/IP Services';                  Roles=@('DomainController','MemberServer');               Level='L1' }
        @{ Name='W3SVC';           Ref='5.x';   Desc='IIS World Wide Web Service';              Roles=@('DomainController');                              Level='L1' }
        @{ Name='XblAuthManager';  Ref='5.x';   Desc='Xbox Live Auth Manager';                  Roles=@('Workstation');                                   Level='L1' }
        @{ Name='XblGameSave';     Ref='5.x';   Desc='Xbox Live Game Save';                     Roles=@('Workstation');                                   Level='L1' }
        @{ Name='XboxNetApiSvc';   Ref='5.x';   Desc='Xbox Network API Service';                Roles=@('Workstation');                                   Level='L1' }
        @{ Name='XboxGipSvc';      Ref='5.x';   Desc='Xbox Accessory Management';               Roles=@('Workstation');                                   Level='L1' }
        @{ Name='bthserv';         Ref='5.x';   Desc='Bluetooth Service (if no BT hardware)';  Roles=@('DomainController','MemberServer');               Level='L2' }
        @{ Name='icssvc';          Ref='5.x';   Desc='Windows Mobile Hotspot Service';          Roles=@('DomainController','MemberServer');               Level='L2' }
        @{ Name='seclogon';        Ref='5.x';   Desc='Secondary Logon — prevent RunAs abuse';  Roles=@('DomainController','MemberServer');               Level='L2' }
        @{ Name='SharedAccess';    Ref='5.x';   Desc='Internet Connection Sharing';             Roles=@('DomainController','MemberServer','Workstation'); Level='L1' }
    )

    # Print Spooler — special handling
    $spoolerDef = @{ Name='Spooler'; Ref='5.29'; Desc='Print Spooler — PrintNightmare mitigation'; Roles=@('DomainController','MemberServer'); Level='L1' }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking services to be disabled..."
        $applicable = $servicesToDisable | Where-Object { $MachineInfo.Role -in $_.Roles -and $Level -ge $_.Level }
        foreach ($svc in $applicable) {
            $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
            if ($s) {
                Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] $($svc.Name): $($s.StartType) / $($s.Status) — $($svc.Desc)"
            } else {
                Write-HardeningLog -Level DEBUG -Module $mod -Message "[AUDIT] $($svc.Name): Not installed (OK)"
            }
        }

        # Spooler check
        if ($MachineInfo.Role -in $spoolerDef.Roles) {
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking Print Spooler queues..."
            $queues = Get-Printer -ErrorAction SilentlyContinue
            if ($queues.Count -gt 0) {
                Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] WARNING: $($queues.Count) active print queue(s) found — Spooler disable will be skipped until queues are migrated"
                foreach ($q in $queues) {
                    Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT]   Queue: $($q.Name) (Driver: $($q.DriverName))"
                }
            } else {
                Write-HardeningLog -Level SUCCESS -Module $mod -Message "[AUDIT] No active print queues — Spooler safe to disable"
            }
        }
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-ServicesHardening-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Services Hardening — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            $applicable = $servicesToDisable | Where-Object {
                $MachineInfo.Role -in $_.Roles -and
                ($_.Level -eq 'L1' -or ($_.Level -eq 'L2' -and $Level -eq 'L2'))
            }

            foreach ($svcDef in $applicable) {
                $svc = Get-Service -Name $svcDef.Name -ErrorAction SilentlyContinue
                if (-not $svc) {
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Service not installed — skip: $($svcDef.Name)"
                    continue
                }

                # Record original state for rollback
                Register-ServiceModified -ServiceName $svcDef.Name `
                    -OriginalStartType $svc.StartType.ToString() `
                    -NewStartType 'Disabled'

                Set-Service -Name $svcDef.Name -StartupType Disabled -ErrorAction Stop
                if ($svc.Status -eq 'Running') {
                    Stop-Service -Name $svcDef.Name -Force -ErrorAction SilentlyContinue
                }
                Write-HardeningLog -Level SUCCESS -Module $mod -Message "Disabled: $($svcDef.Name) — $($svcDef.Desc)"

                # Set via GPO as well for persistence
                Set-GPRegistryValue -Name $gpoName `
                    -Key "HKLM\SYSTEM\CurrentControlSet\Services\$($svcDef.Name)" `
                    -ValueName 'Start' -Type DWord -Value 4 | Out-Null  # 4 = Disabled
            }

            # Print Spooler — role-gated with pre-check
            if ($MachineInfo.Role -in $spoolerDef.Roles) {
                $queues = Get-Printer -ErrorAction SilentlyContinue
                if ($queues.Count -gt 0) {
                    Write-HardeningLog -Level WARN -Module $mod -Message "SKIPPING Spooler disable — $($queues.Count) active print queue(s) found. Migrate queues then re-run with -Module ServicesHardening"
                } else {
                    $spooler = Get-Service -Name 'Spooler' -ErrorAction SilentlyContinue
                    if ($spooler) {
                        Register-ServiceModified -ServiceName 'Spooler' `
                            -OriginalStartType $spooler.StartType.ToString() `
                            -NewStartType 'Disabled'
                        Stop-Service -Name 'Spooler' -Force -ErrorAction SilentlyContinue
                        Set-Service  -Name 'Spooler' -StartupType Disabled -ErrorAction Stop
                        Set-GPRegistryValue -Name $gpoName `
                            -Key 'HKLM\SYSTEM\CurrentControlSet\Services\Spooler' `
                            -ValueName 'Start' -Type DWord -Value 4 | Out-Null
                        Write-HardeningLog -Level SUCCESS -Module $mod -Message "Print Spooler disabled (PrintNightmare mitigation)"
                    }
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Services hardening complete"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Services hardening FAILED: $_"
            throw
        }
    } else {
        $applicable = $servicesToDisable | Where-Object { $MachineInfo.Role -in $_.Roles }
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would disable $($applicable.Count) services on $($MachineInfo.Role)"
        foreach ($s in $applicable) {
            Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF]   $($s.Name) — $($s.Desc)"
        }
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Print Spooler: would check for queues first"
    }
}

Export-ModuleMember -Function Invoke-ServicesHardening
