#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Firewall Policy Module
.DESCRIPTION
    Configures Windows Firewall profiles via GPO.
    All three profiles: Domain, Private, Public.
    CIS Sections: 9.x
#>

function Invoke-FirewallPolicyHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod     = 'FirewallPolicy'
    $fwBase  = 'HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Firewall Policy hardening (Level: $Level)"

    $settings = @(
        # Domain Profile — 9.1.x
        @{ K="$fwBase\DomainProfile"; V='EnableFirewall';             T='DWord'; D=1; R='9.1.1'; Desc='Domain profile: enabled' }
        @{ K="$fwBase\DomainProfile"; V='DefaultInboundAction';       T='DWord'; D=1; R='9.1.2'; Desc='Domain profile: inbound default block' }
        @{ K="$fwBase\DomainProfile"; V='DefaultOutboundAction';      T='DWord'; D=0; R='9.1.3'; Desc='Domain profile: outbound default allow' }
        @{ K="$fwBase\DomainProfile"; V='DisableNotifications';       T='DWord'; D=0; R='9.1.4'; Desc='Domain profile: notify on blocked app' }
        @{ K="$fwBase\DomainProfile"; V='AllowUnicastResponseToMulticast'; T='DWord'; D=0; R='9.1.5'; Desc='Domain profile: no unicast response to multicast' }
        @{ K="$fwBase\DomainProfile\Logging"; V='LogDroppedPackets';  T='DWord'; D=1; R='9.1.6'; Desc='Domain profile: log dropped packets' }
        @{ K="$fwBase\DomainProfile\Logging"; V='LogSuccessfulConnections'; T='DWord'; D=1; R='9.1.7'; Desc='Domain profile: log successful connections' }
        @{ K="$fwBase\DomainProfile\Logging"; V='LogFileSize';        T='DWord'; D=16384; R='9.1.8'; Desc='Domain profile: log size 16MB' }
        @{ K="$fwBase\DomainProfile\Logging"; V='LogFilePath';        T='String'; D='%systemroot%\system32\logfiles\firewall\domainfw.log'; R='9.1.9'; Desc='Domain profile: log path' }

        # Private Profile — 9.2.x
        @{ K="$fwBase\PrivateProfile"; V='EnableFirewall';            T='DWord'; D=1; R='9.2.1'; Desc='Private profile: enabled' }
        @{ K="$fwBase\PrivateProfile"; V='DefaultInboundAction';      T='DWord'; D=1; R='9.2.2'; Desc='Private profile: inbound default block' }
        @{ K="$fwBase\PrivateProfile"; V='DefaultOutboundAction';     T='DWord'; D=0; R='9.2.3'; Desc='Private profile: outbound default allow' }
        @{ K="$fwBase\PrivateProfile"; V='DisableNotifications';      T='DWord'; D=0; R='9.2.4'; Desc='Private profile: notify on blocked app' }
        @{ K="$fwBase\PrivateProfile"; V='AllowUnicastResponseToMulticast'; T='DWord'; D=0; R='9.2.5'; Desc='Private profile: no unicast response to multicast' }
        @{ K="$fwBase\PrivateProfile\Logging"; V='LogDroppedPackets'; T='DWord'; D=1; R='9.2.6'; Desc='Private profile: log dropped packets' }
        @{ K="$fwBase\PrivateProfile\Logging"; V='LogSuccessfulConnections'; T='DWord'; D=1; R='9.2.7'; Desc='Private profile: log successful connections' }
        @{ K="$fwBase\PrivateProfile\Logging"; V='LogFileSize';       T='DWord'; D=16384; R='9.2.8'; Desc='Private profile: log size 16MB' }
        @{ K="$fwBase\PrivateProfile\Logging"; V='LogFilePath';       T='String'; D='%systemroot%\system32\logfiles\firewall\privatefw.log'; R='9.2.9'; Desc='Private profile: log path' }

        # Public Profile — 9.3.x
        @{ K="$fwBase\PublicProfile"; V='EnableFirewall';             T='DWord'; D=1; R='9.3.1'; Desc='Public profile: enabled' }
        @{ K="$fwBase\PublicProfile"; V='DefaultInboundAction';       T='DWord'; D=1; R='9.3.2'; Desc='Public profile: inbound default block' }
        @{ K="$fwBase\PublicProfile"; V='DefaultOutboundAction';      T='DWord'; D=1; R='9.3.3'; Desc='Public profile: outbound default block' }
        @{ K="$fwBase\PublicProfile"; V='DisableNotifications';       T='DWord'; D=1; R='9.3.4'; Desc='Public profile: suppress notifications (no local admin)' }
        @{ K="$fwBase\PublicProfile"; V='AllowUnicastResponseToMulticast'; T='DWord'; D=0; R='9.3.5'; Desc='Public profile: no unicast response to multicast' }
        @{ K="$fwBase\PublicProfile"; V='AllowLocalPolicyMerge';      T='DWord'; D=0; R='9.3.6'; Desc='Public profile: no local policy merge' }
        @{ K="$fwBase\PublicProfile"; V='AllowLocalIPsecPolicyMerge'; T='DWord'; D=0; R='9.3.7'; Desc='Public profile: no local IPsec policy merge' }
        @{ K="$fwBase\PublicProfile\Logging"; V='LogDroppedPackets';  T='DWord'; D=1; R='9.3.8'; Desc='Public profile: log dropped packets' }
        @{ K="$fwBase\PublicProfile\Logging"; V='LogSuccessfulConnections'; T='DWord'; D=1; R='9.3.9'; Desc='Public profile: log successful connections' }
        @{ K="$fwBase\PublicProfile\Logging"; V='LogFileSize';        T='DWord'; D=16384; R='9.3.10'; Desc='Public profile: log size 16MB' }
        @{ K="$fwBase\PublicProfile\Logging"; V='LogFilePath';        T='String'; D='%systemroot%\system32\logfiles\firewall\publicfw.log'; R='9.3.11'; Desc='Public profile: log path' }
    )

    # L2: disable local merge on DC/MS for Domain and Private profiles too
    $l2ServerSettings = @(
        @{ K="$fwBase\DomainProfile";  V='AllowLocalPolicyMerge';     T='DWord'; D=0; R='9.1.x-L2'; Desc='Domain profile: no local policy merge (L2, servers)' }
        @{ K="$fwBase\PrivateProfile"; V='AllowLocalPolicyMerge';     T='DWord'; D=0; R='9.2.x-L2'; Desc='Private profile: no local policy merge (L2, servers)' }
    )

    if ($Level -eq 'L2' -and $MachineInfo.IsServer) { $settings += $l2ServerSettings }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking firewall profile state..."
        try {
            $profiles = Get-NetFirewallProfile -ErrorAction Stop
            foreach ($p in $profiles) {
                Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] $($p.Name): Enabled=$($p.Enabled) InboundAction=$($p.DefaultInboundAction) OutboundAction=$($p.DefaultOutboundAction)"
            }
        } catch {
            Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] Could not read firewall profiles: $_"
        }
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-FirewallPolicy-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Firewall Policy — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            foreach ($s in $settings) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $s.K -ValueName $s.V -Type $s.T -Value $s.D -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set [$($s.R)] $($s.V) = $($s.D)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed: $($s.V): $_"
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Firewall Policy hardening complete — $($settings.Count) settings applied across 3 profiles"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Firewall Policy hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would apply $($settings.Count) firewall settings across Domain, Private, and Public profiles"
    }
}

Export-ModuleMember -Function Invoke-FirewallPolicyHardening
