#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — TLS / SChannel Hardening Module
.DESCRIPTION
    Disables legacy SSL/TLS protocols and weak ciphers via registry.
    Enables TLS 1.2 and 1.3. Enforces cipher suite ordering.
    IMPORTANT: Changes require a REBOOT to take effect.
    CIS Sections: 18.4.x, SCHANNEL registry path
#>

function Invoke-TLSHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod     = 'TLSHardening'
    $schBase = 'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting TLS/SChannel hardening (Level: $Level)"
    Write-HardeningLog -Level WARN -Module $mod -Message "TLS changes require a REBOOT to take effect"

    # Protocol settings: [Name, Client/Server, Enabled, DisabledByDefault]
    $protocols = @(
        @{ Name='SSL 2.0'; Client=$true;  Server=$true;  Enabled=0; DisabledByDefault=1 }
        @{ Name='SSL 3.0'; Client=$true;  Server=$true;  Enabled=0; DisabledByDefault=1 }
        @{ Name='TLS 1.0'; Client=$true;  Server=$true;  Enabled=0; DisabledByDefault=1 }
        @{ Name='TLS 1.1'; Client=$true;  Server=$true;  Enabled=0; DisabledByDefault=1 }
        @{ Name='TLS 1.2'; Client=$true;  Server=$true;  Enabled=1; DisabledByDefault=0 }
        @{ Name='TLS 1.3'; Client=$true;  Server=$true;  Enabled=1; DisabledByDefault=0 }
    )

    # Cipher suites to disable
    $disabledCiphers = @(
        'NULL',
        'DES 56/56',
        'RC2 40/128',
        'RC2 56/128',
        'RC2 128/128',
        'RC4 40/128',
        'RC4 56/128',
        'RC4 64/128',
        'RC4 128/128',
        'Triple DES 168'
    )

    # Hashing algorithms to restrict
    $disabledHashes = @('MD5')
    $l2DisabledHashes = @('SHA')  # L2 only — deprecate SHA-1

    # Key exchange minimum
    $dhMinKeyBits = 2048

    # Preferred cipher suite order (TLS 1.3 first, then TLS 1.2 AES-256)
    $cipherSuiteOrder = @(
        'TLS_AES_256_GCM_SHA384',
        'TLS_AES_128_GCM_SHA256',
        'TLS_CHACHA20_POLY1305_SHA256',
        'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
        'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
        'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
        'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
        'TLS_DHE_RSA_WITH_AES_256_GCM_SHA384',
        'TLS_DHE_RSA_WITH_AES_128_GCM_SHA256'
    )

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking current SChannel configuration..."
        foreach ($proto in $protocols) {
            foreach ($side in @('Client','Server')) {
                if (-not $proto[$side]) { continue }
                $regPath = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\$($proto.Name)\$side"
                $enabled = (Get-ItemProperty -Path $regPath -Name 'Enabled' -ErrorAction SilentlyContinue)?.Enabled
                $status  = if ($null -eq $enabled) { 'Not set (OS default)' } else { if ($enabled -eq 1) { 'ENABLED' } else { 'Disabled' } }
                Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT]   $($proto.Name) $side: $status"
            }
        }
        Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] Enable SChannel EventLogging=7 to capture live negotiation failures before deploying"
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-TLSHardening-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level TLS/SChannel — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            # Protocol enables/disables
            foreach ($proto in $protocols) {
                foreach ($side in @('Client','Server')) {
                    if (-not $proto[$side]) { continue }
                    $regKey = "$schBase\Protocols\$($proto.Name)\$side"
                    Set-GPRegistryValue -Name $gpoName -Key $regKey -ValueName 'Enabled'          -Type DWord -Value $proto.Enabled          | Out-Null
                    Set-GPRegistryValue -Name $gpoName -Key $regKey -ValueName 'DisabledByDefault' -Type DWord -Value $proto.DisabledByDefault | Out-Null
                    $state = if ($proto.Enabled -eq 1) { 'ENABLED' } else { 'disabled' }
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Protocol $($proto.Name) $side : $state"
                }
            }

            # Disable weak ciphers
            foreach ($cipher in $disabledCiphers) {
                $regKey = "$schBase\Ciphers\$cipher"
                Set-GPRegistryValue -Name $gpoName -Key $regKey -ValueName 'Enabled' -Type DWord -Value 0 | Out-Null
                Write-HardeningLog -Level DEBUG -Module $mod -Message "Cipher disabled: $cipher"
            }

            # Disable weak hashes
            $hashesToDisable = $disabledHashes
            if ($Level -eq 'L2') { $hashesToDisable += $l2DisabledHashes }
            foreach ($hash in $hashesToDisable) {
                $regKey = "$schBase\Hashes\$hash"
                Set-GPRegistryValue -Name $gpoName -Key $regKey -ValueName 'Enabled' -Type DWord -Value 0 | Out-Null
                Write-HardeningLog -Level DEBUG -Module $mod -Message "Hash disabled: $hash"
            }

            # Enforce DH minimum key size
            Set-GPRegistryValue -Name $gpoName `
                -Key "$schBase\KeyExchangeAlgorithms\Diffie-Hellman" `
                -ValueName 'ServerMinKeyBitLength' -Type DWord -Value $dhMinKeyBits | Out-Null
            Write-HardeningLog -Level DEBUG -Module $mod -Message "DH minimum key size: $dhMinKeyBits bits"

            # Cipher suite ordering
            $cipherList = $cipherSuiteOrder -join ','
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' `
                -ValueName 'Functions' -Type String -Value $cipherList | Out-Null
            Write-HardeningLog -Level DEBUG -Module $mod -Message "Cipher suite order enforced: $($cipherSuiteOrder.Count) suites"

            # SChannel event logging (useful for ongoing monitoring)
            Set-GPRegistryValue -Name $gpoName `
                -Key $schBase `
                -ValueName 'EventLogging' -Type DWord -Value 1 | Out-Null

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod

            Write-HardeningLog -Level SUCCESS -Module $mod -Message "TLS hardening complete — REBOOT REQUIRED on all targets"
            Write-HardeningLog -Level WARN    -Module $mod -Message "Run Test-TLSReadiness before rebooting to confirm no app compatibility issues"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "TLS hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would configure TLS protocols, ciphers, hashes, and cipher suite order"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Disabled protocols: SSL 2.0, SSL 3.0, TLS 1.0, TLS 1.1"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Enabled protocols: TLS 1.2, TLS 1.3"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Disabled ciphers: $($disabledCiphers -join ', ')"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] DH minimum key: $dhMinKeyBits bits"
        Write-HardeningLog -Level WARN -Module $mod -Message "[WHATIF] REBOOT would be required after applying"
    }
}

function Test-TLSReadiness {
    [CmdletBinding()]
    param()
    $mod = 'TLSHardening'
    Write-HardeningLog -Level INFO -Module $mod -Message "Running TLS readiness check..."

    # Check SChannel event log for recent negotiation failures
    $events = Get-WinEvent -FilterHashtable @{
        LogName   = 'System'
        Id        = @(36871, 36874)
        StartTime = (Get-Date).AddDays(-7)
    } -ErrorAction SilentlyContinue

    if ($events) {
        Write-HardeningLog -Level WARN -Module $mod -Message "Found $($events.Count) SChannel error events in last 7 days — review before deploying TLS changes"
        foreach ($e in $events | Select-Object -First 10) {
            Write-HardeningLog -Level WARN -Module $mod -Message "  [$($e.TimeCreated)] $($e.Message -replace '\s+',' ' | Select-Object -First 200)"
        }
    } else {
        Write-HardeningLog -Level SUCCESS -Module $mod -Message "No SChannel negotiation failures found in last 7 days"
    }
}

Export-ModuleMember -Function Invoke-TLSHardening, Test-TLSReadiness
