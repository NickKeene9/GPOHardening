#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — WinRM Hardening Module
.DESCRIPTION
    Disables WinRM basic auth, unencrypted traffic, digest auth, and
    Windows Remote Shell. Enforces Kerberos/HTTPS only.
    CIS Sections: 18.9.102.x
#>

function Invoke-WinRMHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'WinRMHardening'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting WinRM hardening (Level: $Level)"

    $settings = @(
        # WinRM Client
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client'; V='AllowBasic';           T='DWord'; D=0; R='18.9.102.1.1'; Desc='WinRM client: disable basic auth' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client'; V='AllowUnencryptedTraffic'; T='DWord'; D=0; R='18.9.102.1.2'; Desc='WinRM client: disable unencrypted traffic' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client'; V='AllowDigest';          T='DWord'; D=0; R='18.9.102.1.3'; Desc='WinRM client: disable digest auth' }
        # WinRM Service
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service'; V='AllowBasic';           T='DWord'; D=0; R='18.9.102.2.1'; Desc='WinRM service: disable basic auth' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service'; V='AllowUnencryptedTraffic'; T='DWord'; D=0; R='18.9.102.2.2'; Desc='WinRM service: disable unencrypted traffic' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service'; V='DisableRunAs';         T='DWord'; D=1; R='18.9.102.2.3'; Desc='WinRM service: disable RunAs' }
        # Windows Remote Shell
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS'; V='AllowRemoteShellAccess'; T='DWord'; D=0; R='18.9.102.3'; Desc='Windows Remote Shell: disabled' }
    )

    # L2 additions
    $l2Settings = @(
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service'; V='AllowNegotiate';        T='DWord'; D=0; R='18.9.102.2.x'; Desc='WinRM service: disable Negotiate auth (L2)' }
        @{ K='HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client'; V='AllowNegotiate';         T='DWord'; D=0; R='18.9.102.1.x'; Desc='WinRM client: disable Negotiate auth (L2)' }
    )

    if ($Level -eq 'L2') { $settings += $l2Settings }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking WinRM configuration..."
        try {
            $winrm = Get-WSManInstance -ResourceURI winrm/config/service -ErrorAction SilentlyContinue
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] WinRM Service - Auth\Basic: $($winrm.Auth.Basic)"
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] WinRM Service - AllowUnencrypted: $($winrm.AllowUnencrypted)"
        } catch {
            Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] WinRM not configured or service not running"
        }

        # Check for HTTP listeners
        try {
            $listeners = Get-WSManInstance -ResourceURI winrm/config/listener -SelectorSet @{} -ErrorAction SilentlyContinue
            $httpListeners = @($listeners | Where-Object { $_.Transport -eq 'HTTP' })
            if ($httpListeners.Count -gt 0) {
                Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] $($httpListeners.Count) HTTP WinRM listener(s) found — should be HTTPS only"
            }
        } catch {}
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-WinRMHardening-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level WinRM Hardening — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            foreach ($s in $settings) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $s.K -ValueName $s.V -Type $s.T -Value $s.D -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set [$($s.R)] $($s.V) = $($s.D) — $($s.Desc)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed: $($s.V): $_"
                }
            }

            # Remove HTTP WinRM listener if present (L2)
            if ($Level -eq 'L2') {
                try {
                    $httpListeners = Get-WSManInstance -ResourceURI winrm/config/listener -SelectorSet @{} -ErrorAction SilentlyContinue |
                        Where-Object { $_.Transport -eq 'HTTP' }
                    foreach ($l in $httpListeners) {
                        Remove-WSManInstance -ResourceURI winrm/config/listener -SelectorSet @{ Address=$l.Address; Transport='HTTP' }
                        Write-HardeningLog -Level SUCCESS -Module $mod -Message "Removed HTTP WinRM listener on $($l.Address)"
                    }
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Could not enumerate/remove HTTP WinRM listeners: $_"
                }
            }

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "WinRM hardening complete"
            Write-HardeningLog -Level WARN    -Module $mod -Message "Audit existing PS remoting scripts for HTTP/basic auth before deploying to production"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "WinRM hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would disable WinRM basic auth, unencrypted traffic, digest, and Windows Remote Shell"
        foreach ($s in $settings) {
            Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF]   [$($s.R)] $($s.Desc)"
        }
    }
}

Export-ModuleMember -Function Invoke-WinRMHardening
