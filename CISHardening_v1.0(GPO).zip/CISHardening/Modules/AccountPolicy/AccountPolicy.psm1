#Requires -Version 5.1
#Requires -Modules GroupPolicy
<#
.SYNOPSIS
    CIS Hardening — Account Policy Module
.DESCRIPTION
    Applies CIS password, lockout, and Kerberos policy via GPO.
    CIS Sections: 1.1 (Password), 1.2 (Lockout), 1.3 (Kerberos — DC only)
#>

function Invoke-AccountPolicyHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$ProfileData,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'AccountPolicy'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Account Policy hardening (Level: $Level)"

    $profile = $ProfileData | ConvertFrom-Json

    # ── Password Policy GPO ───────────────────────────────────────────────────
    $gpoName = "CIS-$($MachineInfo.Role)-AccountPolicy-$Level"
    Write-HardeningLog -Level INFO -Module $mod -Message "Creating GPO: $gpoName"

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Would create GPO: $gpoName and link to $DomainControllersOU"
        return
    }

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) {
                Write-HardeningLog -Level WARN -Module $mod -Message "GPO $gpoName already exists — removing and recreating"
                Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue
            }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Account Policy — created by CISHardening script $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "GPO created: $gpoName ($($gpo.Id))"

            # Password policy via secedit INF template applied through GPO
            $secSettings = @{
                'MinimumPasswordLength'        = $profile.PasswordPolicy.MinLength
                'MaximumPasswordAge'           = $profile.PasswordPolicy.MaxAge
                'MinimumPasswordAge'           = $profile.PasswordPolicy.MinAge
                'PasswordHistorySize'          = $profile.PasswordPolicy.History
                'PasswordComplexity'           = 1
                'ClearTextPassword'            = 0
                'LockoutBadCount'              = $profile.LockoutPolicy.Threshold
                'ResetLockoutCount'            = $profile.LockoutPolicy.ResetMinutes
                'LockoutDuration'              = $profile.LockoutPolicy.DurationMinutes
            }

            # Apply via GPO registry settings (Security Settings path)
            $regBase = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'

            Set-GPRegistryValue -Name $gpoName -Key 'HKLM\System\CurrentControlSet\Control\Lsa' `
                -ValueName 'NoLMHash' -Type DWord -Value 1 -ErrorAction Stop | Out-Null

            # Lockout policy keys
            Set-GPRegistryValue -Name $gpoName -Key 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
                -ValueName 'MaxDevicePasswordFailedAttempts' -Type DWord -Value $profile.LockoutPolicy.Threshold | Out-Null

            # Use secedit INF for password + lockout (most reliable method for these settings)
            $infContent = @"
[Unicode]
Unicode=yes
[System Access]
MinimumPasswordLength = $($profile.PasswordPolicy.MinLength)
MaximumPasswordAge = $($profile.PasswordPolicy.MaxAge)
MinimumPasswordAge = $($profile.PasswordPolicy.MinAge)
PasswordHistorySize = $($profile.PasswordPolicy.History)
PasswordComplexity = 1
ClearTextPassword = 0
LockoutBadCount = $($profile.LockoutPolicy.Threshold)
ResetLockoutCount = $($profile.LockoutPolicy.ResetMinutes)
LockoutDuration = $($profile.LockoutPolicy.DurationMinutes)
EnableAdminAccount = 1
EnableGuestAccount = 0
[Version]
signature="`$CHICAGO`$"
Revision = 1
"@
            $infPath = Join-Path $env:TEMP "cis_accountpolicy_$($MachineInfo.Role).inf"
            $infContent | Out-File -FilePath $infPath -Encoding Unicode -Force
            $dbPath = Join-Path $env:TEMP "cis_accountpolicy.sdb"
            & secedit.exe /configure /cfg $infPath /db $dbPath /areas SECURITYPOLICY /quiet 2>&1 | Out-Null

            # Kerberos policy — DC only
            if ($MachineInfo.IsDC) {
                Write-HardeningLog -Level INFO -Module $mod -Message "Applying Kerberos policy (DC role)"

                Set-GPRegistryValue -Name $gpoName `
                    -Key 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters' `
                    -ValueName 'SupportedEncryptionTypes' -Type DWord -Value 0x7FFFFFF8 | Out-Null
                # 0x7FFFFFF8 = AES128+AES256+Future (excludes DES and RC4)

                $kerbInf = @"
[Unicode]
Unicode=yes
[Kerberos Policy]
MaxTicketAge = 10
MaxRenewAge = 7
MaxServiceAge = 600
MaxClockSkew = 5
TicketValidateClient = 1
[Version]
signature="`$CHICAGO`$"
Revision = 1
"@
                $kerbPath = Join-Path $env:TEMP 'cis_kerberos.inf'
                $kerbInf | Out-File -FilePath $kerbPath -Encoding Unicode -Force
                & secedit.exe /configure /cfg $kerbPath /db $dbPath /areas SECURITYPOLICY /quiet 2>&1 | Out-Null
                Write-HardeningLog -Level SUCCESS -Module $mod -Message "Kerberos policy applied (AES-only, ticket 10h, renewal 7d, skew 5min)"
            }

            # Link GPO to Domain Controllers OU
            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -Enforced No -ErrorAction Stop | Out-Null
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "GPO linked to $DomainControllersOU"

            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod

            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Account Policy hardening complete"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Account Policy hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would create and link GPO: $gpoName"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Password min length: $($profile.PasswordPolicy.MinLength)"
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Lockout threshold: $($profile.LockoutPolicy.Threshold)"
    }
}

Export-ModuleMember -Function Invoke-AccountPolicyHardening
