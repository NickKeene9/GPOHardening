#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Defender Policy Module
.DESCRIPTION
    Applies Windows Defender and ASR rules via GPO.
    Supports -ASRMode Audit|Block parameter.
    CIS Sections: 18.10.43.x
#>

function Invoke-DefenderPolicyHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [ValidateSet('Audit','Block')][string]$ASRMode = 'Audit',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'DefenderPolicy'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Defender Policy hardening (Level: $Level, ASR Mode: $ASRMode)"
    if ($ASRMode -eq 'Audit') {
        Write-HardeningLog -Level WARN -Module $mod -Message "ASR rules set to AUDIT mode. Review Event IDs 1121/1122 for 14 days before switching to Block."
    }

    $defBase  = 'HKLM\SOFTWARE\Policies\Microsoft\Windows Defender'
    $rtBase   = "$defBase\Real-Time Protection"
    $spyBase  = "$defBase\Spyware Protection"
    $mapsBase = "$defBase\Spyware Protection"

    # ASR rule GUIDs — 1=Block, 2=Audit, 0=Off
    $asrValue = if ($ASRMode -eq 'Block') { 1 } else { 2 }

    $asrRules = [ordered]@{
        # L1 rules
        'd4f940ab-401b-4efc-aadc-ad5f3c50688a' = @{ Level='L1'; Desc='Block Office apps from creating child processes' }
        'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550' = @{ Level='L1'; Desc='Block executable content in email + webmail' }
        '3b576869-a4ec-4529-8536-b80a7769e899' = @{ Level='L1'; Desc='Block Office apps from creating executable content' }
        '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84' = @{ Level='L1'; Desc='Block Office apps from injecting into other processes' }
        'b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4' = @{ Level='L1'; Desc='Block untrusted/unsigned processes from USB' }
        '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b3' = @{ Level='L1'; Desc='Block credential stealing from LSASS' }
        'd3e037e1-3eb8-44c8-a917-57927947596d' = @{ Level='L1'; Desc='Block JS/VBS from launching downloaded executable content' }
        '5beb7efe-fd9a-4556-801d-275e5ffc04cc' = @{ Level='L1'; Desc='Block execution of obfuscated scripts' }
        '7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c' = @{ Level='L1'; Desc='Block Adobe Reader from creating child processes' }
        'e6db77e5-3df2-4cf1-b95a-636979351e5b' = @{ Level='L1'; Desc='Block persistence through WMI event subscription' }
        '26190899-1602-49e8-8b27-eb1d0a1ce869' = @{ Level='L1'; Desc='Block Office communication apps from creating child processes' }
        'c1db55ab-c21a-4637-bb3f-a12568109d35' = @{ Level='L1'; Desc='Use advanced protection against ransomware' }
        '01443614-cd74-433a-b99e-2ecdc07bfc25' = @{ Level='L1'; Desc='Block executable files unless meet prevalence/age criteria' }
        # L2 rules
        '92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b' = @{ Level='L2'; Desc='Block Win32 API calls from Office macros' }
        'd1e49aac-8f56-4280-b9ba-993a6d77406c' = @{ Level='L2'; Desc='Block process creation from PSExec/WMI' }
        '56a863a9-875e-4185-98a7-b882c64b5ce5' = @{ Level='L2'; Desc='Block abuse of exploited vulnerable signed drivers' }
    }

    $settings = @(
        # Real-time protection
        @{ K=$rtBase; V='DisableRealtimeMonitoring';          T='DWord'; D=0; R='18.10.43.x'; Desc='Real-time monitoring enabled' }
        @{ K=$rtBase; V='DisableBehaviorMonitoring';          T='DWord'; D=0; R='18.10.43.x'; Desc='Behavior monitoring enabled' }
        @{ K=$rtBase; V='DisableOnAccessProtection';          T='DWord'; D=0; R='18.10.43.x'; Desc='On-access protection enabled' }
        @{ K=$rtBase; V='DisableScanOnRealtimeEnable';        T='DWord'; D=0; R='18.10.43.x'; Desc='Scan on real-time enable' }
        @{ K=$rtBase; V='DisableIOAVProtection';              T='DWord'; D=0; R='18.10.43.x'; Desc='IOAV protection enabled' }
        # Cloud protection / MAPS
        @{ K="$defBase\Spyware Protection"; V='SpynetReporting'; T='DWord'; D=2; R='18.10.43.x'; Desc='Cloud-delivered protection: Advanced (2)' }
        @{ K="$defBase\MpEngine";           V='MpCloudBlockLevel'; T='DWord'; D=2; R='18.10.43.x'; Desc='Cloud block level: High' }
        @{ K=$defBase; V='DisableAntiSpyware';                T='DWord'; D=0; R='18.10.43.x'; Desc='Antispyware enabled' }
        # PUA
        @{ K=$defBase; V='PUAProtection';                     T='DWord'; D=1; R='18.10.43.x'; Desc='PUA protection: block (1)' }
        # Signature updates
        @{ K="$defBase\Signature Updates"; V='SignatureUpdateInterval'; T='DWord'; D=8; R='18.10.43.x'; Desc='Signature update interval: 8 hours' }
        # Controlled folder access (L2)
    )

    $l2Settings = @(
        @{ K="$defBase\Windows Defender Exploit Guard\Controlled Folder Access"; V='EnableControlledFolderAccess'; T='DWord'; D=1; R='18.10.43.x'; Desc='Controlled folder access: enabled (L2)' }
    )

    if ($Level -eq 'L2') { $settings += $l2Settings }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Checking current Defender and ASR configuration..."
        try {
            $mpStatus = Get-MpComputerStatus -ErrorAction Stop
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] RealTimeProtectionEnabled: $($mpStatus.RealTimeProtectionEnabled)"
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] AntispywareEnabled: $($mpStatus.AntispywareEnabled)"
        } catch {
            Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] Could not read Defender status: $_"
        }
        # Check for existing ASR audit events (last 14 days)
        $asrEvents = Get-WinEvent -FilterHashtable @{
            LogName   = 'Microsoft-Windows-Windows Defender/Operational'
            Id        = @(1121,1122,1129,1131,1132,1133,1134)
            StartTime = (Get-Date).AddDays(-14)
        } -ErrorAction SilentlyContinue
        if ($asrEvents) {
            Write-HardeningLog -Level WARN -Module $mod -Message "[AUDIT] Found $($asrEvents.Count) ASR events in last 14 days — review before enabling Block mode"
        } else {
            Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] No ASR events found in last 14 days (or ASR not yet enabled)"
        }
        return
    }

    $gpoName = "CIS-$($MachineInfo.Role)-DefenderPolicy-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }
            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Defender Policy ($ASRMode) — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop

            foreach ($s in $settings) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $s.K -ValueName $s.V -Type $s.T -Value $s.D -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set $($s.V) = $($s.D)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed: $($s.V): $_"
                }
            }

            # ASR rules
            $asrRegBase = "$defBase\Windows Defender Exploit Guard\ASR\Rules"
            $applicableRules = $asrRules.GetEnumerator() | Where-Object {
                $_.Value.Level -eq 'L1' -or ($_.Value.Level -eq 'L2' -and $Level -eq 'L2')
            }

            foreach ($rule in $applicableRules) {
                try {
                    Set-GPRegistryValue -Name $gpoName -Key $asrRegBase -ValueName $rule.Key -Type String -Value $asrValue.ToString() -ErrorAction Stop | Out-Null
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "ASR [$ASRMode] $($rule.Value.Desc)"
                } catch {
                    Write-HardeningLog -Level WARN -Module $mod -Message "Failed ASR rule $($rule.Key): $_"
                }
            }

            # Enable ASR rules via GPO
            Set-GPRegistryValue -Name $gpoName `
                -Key "$defBase\Windows Defender Exploit Guard\ASR" `
                -ValueName 'ExploitGuard_ASR_Rules' -Type DWord -Value 1 | Out-Null

            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Defender Policy hardening complete — $($applicableRules.Count) ASR rules set to $ASRMode"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Defender Policy hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would apply $($settings.Count) Defender settings and $($asrRules.Count) ASR rules in $ASRMode mode"
    }
}

Export-ModuleMember -Function Invoke-DefenderPolicyHardening
