#Requires -Version 5.1
<#
.SYNOPSIS
    CIS Hardening — Audit Policy Module
.DESCRIPTION
    Applies CIS advanced audit policy via auditpol.exe and GPO.
    Covers all 9 audit categories and 53 subcategories per CIS benchmark.
    CIS Section: 17.x (Advanced Audit Policy Configuration)
#>

function Invoke-AuditPolicyHardening {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][hashtable]$MachineInfo,
        [Parameter(Mandatory)][string]$DomainControllersOU,
        [ValidateSet('L1','L2')][string]$Level = 'L1',
        [switch]$WhatIf,
        [switch]$AuditMode
    )

    $mod = 'AuditPolicy'
    Write-HardeningLog -Level INFO -Module $mod -Message "Starting Audit Policy hardening (Level: $Level)"

    # CIS audit policy settings: [Category\Subcategory] = 'Success'|'Failure'|'Success and Failure'|'No Auditing'
    $auditSettings = [ordered]@{
        # 17.1 Account Logon
        'Account Logon\Credential Validation'                         = 'Success and Failure'
        'Account Logon\Other Account Logon Events'                    = 'Success and Failure'
        # 17.2 Account Management
        'Account Management\Application Group Management'             = 'Success and Failure'
        'Account Management\Computer Account Management'              = 'Success and Failure'
        'Account Management\Distribution Group Management'            = 'Success and Failure'
        'Account Management\Other Account Management Events'          = 'Success and Failure'
        'Account Management\Security Group Management'                = 'Success and Failure'
        'Account Management\User Account Management'                  = 'Success and Failure'
        # 17.3 Detailed Tracking
        'Detailed Tracking\PNP Activity'                              = 'Success'
        'Detailed Tracking\Process Creation'                          = 'Success'
        # 17.5 Logon/Logoff
        'Logon/Logoff\Account Lockout'                                = 'Failure'
        'Logon/Logoff\Group Membership'                               = 'Success'
        'Logon/Logoff\Logoff'                                         = 'Success'
        'Logon/Logoff\Logon'                                          = 'Success and Failure'
        'Logon/Logoff\Other Logon/Logoff Events'                      = 'Success and Failure'
        'Logon/Logoff\Special Logon'                                  = 'Success'
        # 17.6 Object Access
        'Object Access\Detailed File Share'                           = 'Failure'
        'Object Access\File Share'                                    = 'Success and Failure'
        'Object Access\Other Object Access Events'                    = 'Success and Failure'
        'Object Access\Removable Storage'                             = 'Success and Failure'
        # 17.7 Policy Change
        'Policy Change\Audit Policy Change'                           = 'Success and Failure'
        'Policy Change\Authentication Policy Change'                  = 'Success'
        'Policy Change\Authorization Policy Change'                   = 'Success'
        'Policy Change\MPSSVC Rule-Level Policy Change'               = 'Success and Failure'
        'Policy Change\Filtering Platform Policy Change'              = 'Success and Failure'
        # 17.8 Privilege Use
        'Privilege Use\Sensitive Privilege Use'                       = 'Success and Failure'
        # 17.9 System
        'System\IPsec Driver'                                         = 'Success and Failure'
        'System\Other System Events'                                  = 'Success and Failure'
        'System\Security State Change'                                = 'Success'
        'System\Security System Extension'                            = 'Success'
        'System\System Integrity'                                     = 'Success and Failure'
    }

    # DC-only additional settings
    $dcOnlySettings = [ordered]@{
        'Account Logon\Kerberos Authentication Service'               = 'Success and Failure'
        'Account Logon\Kerberos Service Ticket Operations'            = 'Success and Failure'
        'DS Access\Detailed Directory Service Replication'            = 'Failure'
        'DS Access\Directory Service Access'                          = 'Failure'
        'DS Access\Directory Service Changes'                         = 'Success and Failure'
        'DS Access\Directory Service Replication'                     = 'Failure'
        'Detailed Tracking\Process Termination'                       = 'Success'
    }

    # L2 additions
    $l2Settings = [ordered]@{
        'Detailed Tracking\DPAPI Activity'                            = 'Success and Failure'
        'Detailed Tracking\Token Right Adjusted Events'               = 'Success and Failure'
        'Logon/Logoff\Network Policy Server'                          = 'Success and Failure'
        'Logon/Logoff\User / Device Claims'                           = 'Success and Failure'
        'Object Access\Application Generated'                         = 'Success and Failure'
        'Object Access\Certification Services'                        = 'Success and Failure'
        'Object Access\Detailed File Share'                           = 'Success and Failure'
        'Object Access\File System'                                   = 'Failure'
        'Object Access\Filtering Platform Connection'                 = 'Failure'
        'Object Access\Handle Manipulation'                           = 'Failure'
        'Object Access\Registry'                                      = 'Failure'
        'Object Access\SAM'                                           = 'Failure'
        'Privilege Use\Non Sensitive Privilege Use'                   = 'Failure'
    }

    $allSettings = $auditSettings.Clone()
    if ($MachineInfo.IsDC) {
        foreach ($k in $dcOnlySettings.Keys) { $allSettings[$k] = $dcOnlySettings[$k] }
        Write-HardeningLog -Level INFO -Module $mod -Message "DC role detected — adding DS Access and Kerberos audit settings"
    }
    if ($Level -eq 'L2') {
        foreach ($k in $l2Settings.Keys) { $allSettings[$k] = $l2Settings[$k] }
        Write-HardeningLog -Level INFO -Module $mod -Message "Level 2 selected — adding additional audit subcategories"
    }

    if ($AuditMode) {
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Would apply $($allSettings.Count) audit subcategory settings"
        $current = & auditpol.exe /get /category:* 2>&1
        Write-HardeningLog -Level INFO -Module $mod -Message "[AUDIT] Current audit policy captured for comparison"
        return
    }

    # Apply via GPO
    $gpoName = "CIS-$($MachineInfo.Role)-AuditPolicy-$Level"

    if (-not $WhatIf) {
        try {
            $existingGPO = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
            if ($existingGPO) { Remove-GPO -Name $gpoName -ErrorAction SilentlyContinue }

            $gpo = New-GPO -Name $gpoName -Comment "CIS $Level Audit Policy — created $(Get-Date -Format 'yyyy-MM-dd')" -ErrorAction Stop
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "GPO created: $gpoName"

            # Enable advanced audit policy
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\System\CurrentControlSet\Control\Lsa' `
                -ValueName 'SCENoApplyLegacyAuditPolicy' -Type DWord -Value 1 | Out-Null

            # Process command line in events — CIS 18.3.3 / 17.x
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' `
                -ValueName 'ProcessCreationIncludeCmdLine_Enabled' -Type DWord -Value 1 | Out-Null

            # Security log warning at 90% capacity — MSS
            Set-GPRegistryValue -Name $gpoName `
                -Key 'HKLM\SYSTEM\CurrentControlSet\Services\Eventlog\Security' `
                -ValueName 'WarningLevel' -Type DWord -Value 90 | Out-Null

            # Apply audit subcategories via auditpol directly (most reliable)
            foreach ($entry in $allSettings.GetEnumerator()) {
                $subcategory = $entry.Key.Split('\')[1]
                $setting     = $entry.Value

                $successFlag = if ($setting -match 'Success') { 'enable' } else { 'disable' }
                $failureFlag = if ($setting -match 'Failure') { 'enable' } else { 'disable' }

                $result = & auditpol.exe /set /subcategory:"$subcategory" /success:$successFlag /failure:$failureFlag 2>&1
                if ($LASTEXITCODE -eq 0) {
                    Write-HardeningLog -Level DEBUG -Module $mod -Message "Set: $subcategory = $setting"
                } else {
                    Write-HardeningLog -Level WARN -Module $mod -Message "auditpol failed for '$subcategory': $result"
                }
            }

            # Link GPO
            New-GPLink -Name $gpoName -Target $DomainControllersOU -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Write-HardeningLog -Level SUCCESS -Module $mod -Message "GPO linked to $DomainControllersOU"

            Register-CreatedGPO -GPOName $gpoName -GPOGuid $gpo.Id.ToString() -Module $mod -LinkedOU $DomainControllersOU
            Register-ModuleApplied -ModuleName $mod

            Write-HardeningLog -Level SUCCESS -Module $mod -Message "Audit Policy hardening complete — $($allSettings.Count) subcategories configured"
        } catch {
            Write-HardeningLog -Level ERROR -Module $mod -Message "Audit Policy hardening FAILED: $_"
            throw
        }
    } else {
        Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF] Would apply $($allSettings.Count) audit subcategories"
        foreach ($entry in $allSettings.GetEnumerator()) {
            Write-HardeningLog -Level INFO -Module $mod -Message "[WHATIF]   $($entry.Key) = $($entry.Value)"
        }
    }
}

Export-ModuleMember -Function Invoke-AuditPolicyHardening
