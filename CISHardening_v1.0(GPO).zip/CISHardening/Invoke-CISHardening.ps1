#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    CIS AD GPO Hardening Script — Main Orchestrator
.DESCRIPTION
    Applies CIS Benchmark hardening controls via GPO to Active Directory
    Domain Controllers, Member Servers, and Workstations.

    Targets: Windows Server 2019, 2022, Windows 10, Windows 11
    Baseline: CIS Level 1 and Level 2 (selectable per run)
    GPO Strategy: Creates named GPO objects linked to the Domain Controllers OU

.PARAMETER Level
    CIS benchmark level. L1 (default) or L2.

.PARAMETER Role
    Override role detection. Auto-detected if not specified.

.PARAMETER Modules
    Comma-separated list of modules to run. Runs all applicable if not specified.

.PARAMETER WhatIf
    Preview all changes without applying anything.

.PARAMETER AuditMode
    Run pre-deployment readiness checks only. No changes applied.

.PARAMETER Rollback
    Invoke rollback from a previous snapshot.

.PARAMETER RollbackPath
    Path to the rollback snapshot folder (required with -Rollback).

.PARAMETER RollbackModule
    Rollback a specific module only. Default: All.

.PARAMETER ASRMode
    Attack Surface Reduction mode: Audit (default) or Block.

.PARAMETER OutputPath
    Base output path for logs, reports, and rollback snapshots.
    Default: .\CISHardening_Output

.PARAMETER SkipSnapshot
    Skip pre-flight snapshot (not recommended).

.EXAMPLE
    .\Invoke-CISHardening.ps1 -WhatIf
    Preview all changes for the detected role.

.EXAMPLE
    .\Invoke-CISHardening.ps1 -Level L1 -AuditMode
    Run pre-deployment readiness checks only.

.EXAMPLE
    .\Invoke-CISHardening.ps1 -Level L1
    Apply all L1 controls for the detected role.

.EXAMPLE
    .\Invoke-CISHardening.ps1 -Level L2 -ASRMode Block -Modules DefenderPolicy
    Apply only the Defender module in Block mode.

.EXAMPLE
    .\Invoke-CISHardening.ps1 -Rollback -RollbackPath .\CISHardening_Output\Rollback\20241201_143022
    Roll back all changes from a previous run.

.EXAMPLE
    .\Invoke-CISHardening.ps1 -Rollback -RollbackPath .\CISHardening_Output\Rollback\20241201_143022 -RollbackModule TLSHardening
    Roll back only the TLS module changes.
#>

[CmdletBinding(DefaultParameterSetName = 'Apply', SupportsShouldProcess)]
param(
    [Parameter(ParameterSetName = 'Apply')]
    [Parameter(ParameterSetName = 'Audit')]
    [ValidateSet('L1', 'L2')]
    [string]$Level = 'L1',

    [Parameter(ParameterSetName = 'Apply')]
    [Parameter(ParameterSetName = 'Audit')]
    [ValidateSet('DomainController', 'MemberServer', 'Workstation', 'Auto')]
    [string]$Role = 'Auto',

    [Parameter(ParameterSetName = 'Apply')]
    [Parameter(ParameterSetName = 'Audit')]
    [string[]]$Modules = @(),

    [Parameter(ParameterSetName = 'Apply')]
    [switch]$WhatIf,

    [Parameter(ParameterSetName = 'Audit', Mandatory)]
    [switch]$AuditMode,

    [Parameter(ParameterSetName = 'Rollback', Mandatory)]
    [switch]$Rollback,

    [Parameter(ParameterSetName = 'Rollback', Mandatory)]
    [string]$RollbackPath,

    [Parameter(ParameterSetName = 'Rollback')]
    [string]$RollbackModule = 'All',

    [Parameter(ParameterSetName = 'Apply')]
    [ValidateSet('Audit', 'Block')]
    [string]$ASRMode = 'Audit',

    [string]$OutputPath = '.\CISHardening_Output',

    [switch]$SkipSnapshot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── Resolve paths ─────────────────────────────────────────────────────────────
$ScriptRoot  = $PSScriptRoot
$ModulesPath = Join-Path $ScriptRoot 'Modules'
$ProfilesPath= Join-Path $ScriptRoot 'Profiles'
$OutputPath  = [System.IO.Path]::GetFullPath($OutputPath)
$null = New-Item -ItemType Directory -Path $OutputPath -Force

# ── Load core modules ─────────────────────────────────────────────────────────
$coreModules = @('Logging', 'RoleDetection', 'Snapshot')
foreach ($cm in $coreModules) {
    $path = Join-Path $ModulesPath "Core\$cm.psm1"
    if (-not (Test-Path $path)) { throw "Core module not found: $path" }
    Import-Module $path -Force -Global
}

# ── Initialise logging ─────────────────────────────────────────────────────────
Initialize-HardeningLog -OutputPath $OutputPath -Level INFO -WhatIf:$WhatIf

Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "========================================"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  CIS AD GPO Hardening Script v1.0"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Mode     : $(if($Rollback){'ROLLBACK'}elseif($AuditMode){'AUDIT'}elseif($WhatIf){'WHATIF'}else{'APPLY'})"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Level    : CIS $Level"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  ASR Mode : $ASRMode"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Output   : $OutputPath"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "========================================"

# ── Rollback mode ─────────────────────────────────────────────────────────────
if ($Rollback) {
    Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "ROLLBACK MODE — this will reverse hardening changes"
    Assert-GroupPolicyModuleAvailable
    Invoke-HardeningRollback -RollbackPath $RollbackPath -Module $RollbackModule -WhatIf:$WhatIf
    Close-HardeningLog
    exit 0
}

# ── Role detection ────────────────────────────────────────────────────────────
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Detecting machine role..."
$MachineInfo = Get-MachineRole

if ($Role -ne 'Auto') {
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Role override: $Role (detected: $($MachineInfo.Role))"
    $MachineInfo.Role          = $Role
    $MachineInfo.IsDC          = ($Role -eq 'DomainController')
    $MachineInfo.IsMemberServer= ($Role -eq 'MemberServer')
    $MachineInfo.IsWorkstation = ($Role -eq 'Workstation')
    $MachineInfo.IsServer      = ($Role -in 'DomainController','MemberServer')
}

Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Role         : $($MachineInfo.Role)"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "OS           : $($MachineInfo.OSCaption) (Build $($MachineInfo.OSBuild))"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Domain       : $($MachineInfo.Domain)"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Computer     : $($MachineInfo.ComputerName)"

if ($MachineInfo.Role -eq 'Unknown') {
    Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "Unable to determine machine role. Use -Role to override."
    Close-HardeningLog
    exit 1
}

# ── Validate required modules ─────────────────────────────────────────────────
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Checking prerequisites..."
try {
    Assert-ADModuleAvailable
    Assert-GroupPolicyModuleAvailable
    Write-HardeningLog -Level SUCCESS -Module 'Orchestrator' -Message "ActiveDirectory and GroupPolicy modules available"
} catch {
    Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "Prerequisites check failed: $_"
    Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "Install RSAT: Add-WindowsFeature RSAT-AD-Tools,GPMC"
    Close-HardeningLog
    exit 1
}

# ── Load role profile ─────────────────────────────────────────────────────────
$profileFile = Join-Path $ProfilesPath "$($MachineInfo.Role).json"
if (-not (Test-Path $profileFile)) {
    Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "Profile not found: $profileFile"
    Close-HardeningLog
    exit 1
}
$profileData    = Get-Content $profileFile -Raw
$profileObj     = $profileData | ConvertFrom-Json
$moduleSequence = $profileObj.Modules
$skipModules    = $profileObj.SkipModules

if ($Modules.Count -gt 0) {
    $moduleSequence = $Modules
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Module filter applied: $($Modules -join ', ')"
}

Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Modules to run: $($moduleSequence -join ', ')"

# ── Domain Controllers OU ─────────────────────────────────────────────────────
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Resolving Domain Controllers OU..."
$DCOU = Get-DomainControllersOU
if (-not $DCOU) {
    Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "Could not resolve Domain Controllers OU. Must run from a domain-joined machine."
    Close-HardeningLog
    exit 1
}
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "DC OU: $DCOU"

# ── Pre-flight snapshot ────────────────────────────────────────────────────────
if (-not $AuditMode -and -not $SkipSnapshot) {
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Taking pre-flight snapshot..."
    $snapshotDir = New-RollbackSnapshot -BaseOutputPath $OutputPath -WhatIf:$WhatIf
    Write-HardeningLog -Level SUCCESS -Module 'Orchestrator' -Message "Snapshot: $snapshotDir"
} elseif ($AuditMode) {
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Audit mode — skipping snapshot"
}

# ── Module loader ─────────────────────────────────────────────────────────────
function Import-HardeningModule {
    param([string]$ModuleName)
    $path = Join-Path $ModulesPath "$ModuleName\$ModuleName.psm1"
    if (-not (Test-Path $path)) {
        Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "Module file not found: $path — skipping"
        return $false
    }
    Import-Module $path -Force -Global
    return $true
}

# ── Module dispatch table ─────────────────────────────────────────────────────
$moduleDispatch = @{

    'AccountPolicy' = {
        if (Import-HardeningModule 'AccountPolicy') {
            Invoke-AccountPolicyHardening `
                -MachineInfo $MachineInfo `
                -ProfileData $profileData `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'AuditPolicy' = {
        if (Import-HardeningModule 'AuditPolicy') {
            Invoke-AuditPolicyHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'SecurityOptions' = {
        if (Import-HardeningModule 'SecurityOptions') {
            Invoke-SecurityOptionsHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'UserRights' = {
        if (Import-HardeningModule 'UserRights') {
            Invoke-UserRightsHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'TLSHardening' = {
        if (Import-HardeningModule 'TLSHardening') {
            if ($AuditMode) { Test-TLSReadiness }
            Invoke-TLSHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'NetworkHardening' = {
        if (Import-HardeningModule 'NetworkHardening') {
            Invoke-NetworkHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'WinRMHardening' = {
        if (Import-HardeningModule 'WinRMHardening') {
            Invoke-WinRMHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'ServicesHardening' = {
        if (Import-HardeningModule 'ServicesHardening') {
            Invoke-ServicesHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'RegistryHardening' = {
        if (Import-HardeningModule 'RegistryHardening') {
            Invoke-RegistryHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'FirewallPolicy' = {
        if (Import-HardeningModule 'FirewallPolicy') {
            Invoke-FirewallPolicyHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'DefenderPolicy' = {
        if (Import-HardeningModule 'DefenderPolicy') {
            Invoke-DefenderPolicyHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -ASRMode $ASRMode `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'PrivilegedAccess' = {
        if (Import-HardeningModule 'PrivilegedAccess') {
            Invoke-PrivilegedAccessHardening `
                -MachineInfo $MachineInfo `
                -DomainControllersOU $DCOU `
                -Level $Level `
                -WhatIf:$WhatIf `
                -AuditMode:$AuditMode
        }
    }

    'HardeningReport' = {
        if (Import-HardeningModule 'HardeningReport') {
            Invoke-HardeningReport `
                -MachineInfo $MachineInfo `
                -OutputPath $OutputPath `
                -Level $Level
        }
    }
}

# ── Execute modules ───────────────────────────────────────────────────────────
$succeeded = [System.Collections.Generic.List[string]]::new()
$failed    = [System.Collections.Generic.List[string]]::new()
$skipped   = [System.Collections.Generic.List[string]]::new()

foreach ($moduleName in $moduleSequence) {

    if ($moduleName -in $skipModules) {
        Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "Skipping $moduleName (profile exclusion)"
        $skipped.Add($moduleName)
        continue
    }

    if (-not $moduleDispatch.ContainsKey($moduleName)) {
        Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "No dispatch entry for module: $moduleName"
        $skipped.Add($moduleName)
        continue
    }

    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "--- Running module: $moduleName ---"
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    try {
        & $moduleDispatch[$moduleName]
        $sw.Stop()
        Write-HardeningLog -Level SUCCESS -Module 'Orchestrator' -Message "$moduleName completed in $($sw.Elapsed.TotalSeconds.ToString('F1'))s"
        $succeeded.Add($moduleName)
    } catch {
        $sw.Stop()
        Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "$moduleName FAILED after $($sw.Elapsed.TotalSeconds.ToString('F1'))s: $_"
        $failed.Add($moduleName)

        # Continue to next module unless it's a critical core failure
        if ($moduleName -in @('AccountPolicy','UserRights')) {
            Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "Critical module failed — continuing with remaining modules"
        }
    }
}

# ── Final summary ─────────────────────────────────────────────────────────────
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "========================================"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  RUN SUMMARY"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Host     : $($MachineInfo.ComputerName)"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Role     : $($MachineInfo.Role)"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Level    : CIS $Level"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Mode     : $(if($AuditMode){'AUDIT'}elseif($WhatIf){'WHATIF'}else{'APPLIED'})"
Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Succeeded: $($succeeded.Count) — $($succeeded -join ', ')"
if ($failed.Count -gt 0) {
    Write-HardeningLog -Level ERROR -Module 'Orchestrator' -Message "  Failed   : $($failed.Count) — $($failed -join ', ')"
}
if ($skipped.Count -gt 0) {
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Skipped  : $($skipped.Count) — $($skipped -join ', ')"
}

$snapshotPath = Get-SnapshotPath
if ($snapshotPath) {
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  Rollback : $snapshotPath"
    Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "  To rollback: .\Invoke-CISHardening.ps1 -Rollback -RollbackPath '$snapshotPath'"
}

if (-not $AuditMode -and -not $WhatIf -and $succeeded.Count -gt 0) {
    Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "Run 'gpupdate /force' on all target machines to apply GPO changes"
    if ($succeeded -contains 'TLSHardening') {
        Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "TLS changes require a REBOOT on all targets to take effect"
    }
    if ($succeeded -contains 'RegistryHardening') {
        Write-HardeningLog -Level WARN -Module 'Orchestrator' -Message "Credential Guard requires a REBOOT + UEFI hardware support"
    }
}

Write-HardeningLog -Level INFO -Module 'Orchestrator' -Message "========================================"
Close-HardeningLog

exit $(if ($failed.Count -gt 0) { 1 } else { 0 })
